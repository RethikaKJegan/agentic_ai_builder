import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Bot, Plus } from "lucide-react";
import { useMesh } from "@/domain/store";
import { getModel } from "@/domain/models";
import { AgentInspector } from "@/features/agents/AgentInspector";

export const Route = createFileRoute("/app/agents")({
  validateSearch: (s: Record<string, unknown>): { agent?: string } => (typeof s["agent"] === "string" ? { agent: s["agent"] } : {}),
  head: () => ({
    meta: [
      { title: "Agents — MESH" },
      { name: "description", content: "Reusable AI agents with models, tools, knowledge and guardrails." },
      { property: "og:title", content: "Agents — MESH" },
      { property: "og:description", content: "Reusable AI agents with models, tools, knowledge and guardrails." },
    ],
  }),
  component: AgentsPage,
});

function AgentsPage() {
  const { agent: selectedId } = Route.useSearch();
  const navigate = useNavigate({ from: "/app/agents" });
  const agents = useMesh((s) => s.agents);
  const workflows = useMesh((s) => s.workflows);
  const createAgent = useMesh((s) => s.createAgent);
  const selected = agents.find((a) => a.id === selectedId) ?? agents[0];
  const usedIn = (id: string) => workflows.filter((w) => w.nodes.some((n) => n.data.agentId === id));

  return (
    <div className="flex h-full flex-col lg:flex-row">
      <div className="min-w-0 flex-1 overflow-y-auto px-6 py-10">
        <div className="flex items-end justify-between gap-4">
          <h1 className="text-3xl font-semibold">Agents</h1>
          <div className="flex gap-2">
            <Link to="/app/marketplace" className="inline-flex h-9 items-center rounded-lg border border-border px-3.5 text-sm hover:border-primary hover:text-primary">Browse marketplace</Link>
            <button onClick={() => navigate({ search: { agent: createAgent() } })} className="inline-flex h-9 items-center gap-1.5 rounded-lg bg-primary px-3.5 text-sm font-medium text-primary-foreground hover:bg-primary-deep"><Plus className="h-4 w-4" />New agent</button>
          </div>
        </div>
        <p className="mt-2 text-sm text-muted-foreground">Reusable agents. Changes here apply everywhere they're used.</p>
        {agents.length === 0 ? (
          <p className="mt-8 rounded-xl border border-dashed border-border p-6 text-sm text-muted-foreground">Agents appear here when you generate a workflow. <Link to="/app" className="text-primary">Create one</Link>.</p>
        ) : (
          <div className="mt-8 divide-y divide-border rounded-xl border border-border">
            {agents.map((a) => {
              const uses = usedIn(a.id);
              return (
                <button key={a.id} onClick={() => navigate({ search: { agent: a.id } })} className={`flex w-full items-center gap-4 px-4 py-3.5 text-left transition-colors ${selected?.id === a.id ? "bg-highlight" : "hover:bg-canvas"}`}>
                  <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary text-primary-foreground"><Bot className="h-4 w-4" /></span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-medium">{a.name}</p>
                    <p className="truncate text-xs text-muted-foreground">{a.role} · {getModel(a.modelId).name}</p>
                  </div>
                  <span className="hidden text-xs text-muted-foreground sm:inline">{uses.length ? `in ${uses[0]!.name}${uses.length > 1 ? ` +${uses.length - 1}` : ""}` : "unused"}</span>
                </button>
              );
            })}
          </div>
        )}
      </div>
      {selected && (
        <aside className="w-full shrink-0 overflow-y-auto border-t border-border p-5 lg:w-[380px] lg:border-l lg:border-t-0">
          <h2 className="mb-4 text-lg font-medium">{selected.name}</h2>
          <AgentInspector agent={selected} />
        </aside>
      )}
    </div>
  );
}
