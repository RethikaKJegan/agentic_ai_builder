// Governance: demo roles/permissions, policies with inheritance, and run metrics.
// Pure functions so UI and tests share one implementation.
import type { Run } from "./types";

export type Role = "admin" | "builder" | "approver" | "viewer";
export type Permission = "workflow.edit" | "workflow.publish" | "run.test" | "approval.decide" | "policy.manage" | "settings.manage";

export const ROLES: { id: Role; label: string; description: string }[] = [
  { id: "admin", label: "Organization Admin", description: "Full control, including policies and settings." },
  { id: "builder", label: "Builder", description: "Designs, tests and publishes workflows." },
  { id: "approver", label: "Approver", description: "Reviews paused runs and decides approvals." },
  { id: "viewer", label: "Viewer", description: "Read-only access to workflows, runs and monitoring." },
];

const MATRIX: Record<Role, Permission[]> = {
  admin: ["workflow.edit", "workflow.publish", "run.test", "approval.decide", "policy.manage", "settings.manage"],
  builder: ["workflow.edit", "workflow.publish", "run.test"],
  approver: ["run.test", "approval.decide"],
  viewer: [],
};

export const can = (role: Role, p: Permission) => MATRIX[role].includes(p);
export const roleLabel = (r: Role) => ROLES.find((x) => x.id === r)?.label ?? r;

export type GuardrailKey = "piiRedaction" | "injectionDetection" | "outputValidation";
export type PolicyRule =
  | { type: "require-guardrail"; guardrail: GuardrailKey }
  | { type: "block-model"; modelId: string }
  | { type: "max-run-cost"; usd: number };

export interface Policy {
  id: string;
  scope: "organization" | "workspace";
  name: string;
  description: string;
  rule: PolicyRule;
  enabled: boolean;
}

export interface EffectivePolicy {
  guardrails: Record<GuardrailKey, boolean>;
  blockedModels: string[];
  maxRunCost: number | null;
  /** Which policy produced each effective setting. */
  sources: { setting: string; policy: string; scope: Policy["scope"] }[];
}

/** Workspace policies can only tighten organization policies: guardrails and blocks union, cost caps take the minimum. */
export function effectivePolicy(policies: Policy[]): EffectivePolicy {
  const eff: EffectivePolicy = { guardrails: { piiRedaction: false, injectionDetection: false, outputValidation: false }, blockedModels: [], maxRunCost: null, sources: [] };
  const ordered = [...policies.filter((p) => p.scope === "organization"), ...policies.filter((p) => p.scope === "workspace")];
  for (const p of ordered) {
    if (!p.enabled) continue;
    const r = p.rule;
    if (r.type === "require-guardrail") {
      eff.guardrails[r.guardrail] = true;
      eff.sources.push({ setting: `Guardrail: ${r.guardrail}`, policy: p.name, scope: p.scope });
    } else if (r.type === "block-model") {
      if (!eff.blockedModels.includes(r.modelId)) eff.blockedModels.push(r.modelId);
      eff.sources.push({ setting: `Blocked model: ${r.modelId}`, policy: p.name, scope: p.scope });
    } else if (eff.maxRunCost === null || r.usd < eff.maxRunCost) {
      eff.maxRunCost = r.usd;
      eff.sources.push({ setting: `Max run cost: $${r.usd}`, policy: p.name, scope: p.scope });
    }
  }
  return eff;
}

export function runMetrics(runs: Run[]) {
  const total = runs.length;
  const finished = runs.filter((r) => r.status !== "paused" && r.status !== "running");
  const completed = runs.filter((r) => r.status === "completed").length;
  const cost = runs.reduce((a, r) => a + r.steps.reduce((b, s) => b + s.cost, 0), 0);
  const latency = runs.reduce((a, r) => a + r.steps.reduce((b, s) => b + s.latencyMs, 0), 0);
  return {
    total,
    completed,
    pending: runs.filter((r) => r.status === "paused").length,
    blocked: runs.filter((r) => r.status === "blocked").length,
    failed: runs.filter((r) => r.status === "failed" || r.status === "rejected").length,
    successRate: finished.length ? completed / finished.length : 0,
    cost: +cost.toFixed(4),
    avgLatencyMs: total ? Math.round(latency / total) : 0,
  };
}
