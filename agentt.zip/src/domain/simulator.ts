// Deterministic run simulator. Walks the graph from triggers, following condition
// branches, pausing at approvals without a decision. Re-running with decisions resumes.
import { getModel } from "./models";
import type { Agent, NodeKind, RunStatus, RunStep, Workflow } from "./types";
import type { EffectivePolicy } from "./governance";

export const CRITICAL_PATTERN = /critical|urgent|lawsuit|legal|furious|unacceptable|cancel|over \$?10,?000|\$\d{2},\d{3}|high[- ]fit|enterprise/i;
export const INJECTION_PATTERN = /ignore (all |previous |prior )?instructions|system prompt|jailbreak/i;
export const FAIL_PATTERN = /#fail/i;

export interface SimResult {
  status: RunStatus;
  steps: RunStep[];
  branch: "critical" | "standard";
}

function hash(s: string) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
  return Math.abs(h);
}

const baseLatency: Record<NodeKind, number> = { trigger: 40, agent: 1400, tool: 320, condition: 25, approval: 0, transform: 60, output: 260 };

export function simulateRun(
  wf: Pick<Workflow, "nodes" | "edges">,
  agents: Agent[],
  input: string,
  decisions: Record<string, "approved" | "rejected"> = {},
  policy?: EffectivePolicy,
): SimResult {
  let spent = 0;
  const branch: "critical" | "standard" = CRITICAL_PATTERN.test(input) ? "critical" : "standard";
  const injection = INJECTION_PATTERN.test(input);
  const forceFail = FAIL_PATTERN.test(input);
  const hasIncoming = new Set(wf.edges.map((e) => e.target));
  const queue = wf.nodes.filter((n) => !hasIncoming.has(n.id)).map((n) => n.id);
  const visited = new Set<string>();
  const steps: RunStep[] = [];
  let failedOnce = false;

  while (queue.length) {
    const id = queue.shift()!;
    if (visited.has(id)) continue;
    // Wait until all reachable predecessors that are on the active path are done (simple join).
    visited.add(id);
    const node = wf.nodes.find((n) => n.id === id);
    if (!node) continue;
    const { kind, label } = node.data;
    const seed = hash(id + input);
    const step: RunStep = { nodeId: id, label, kind, status: "success", output: "", latencyMs: Math.round(baseLatency[kind] * (0.8 + (seed % 40) / 100)), tokens: 0, cost: 0 };

    if (kind === "agent") {
      const agent = agents.find((a) => a.id === node.data.agentId);
      const model = getModel(agent?.modelId ?? "gpt-5-mini");
      step.modelId = model.id;
      step.tokens = 600 + (seed % 900);
      step.latencyMs = Math.round(step.latencyMs * model.speed);
      step.cost = +((step.tokens / 1000) * model.costPer1k).toFixed(4);
      if (policy?.blockedModels.includes(model.id)) {
        step.status = "blocked";
        step.tokens = 0;
        step.cost = 0;
        step.guardrail = `Policy: ${model.name} is not allowed in this workspace`;
        step.output = "Execution blocked by policy before model call.";
        steps.push(step);
        return { status: "blocked", steps, branch };
      }
      if (injection && ((agent?.guardrails.injectionDetection ?? true) || policy?.guardrails.injectionDetection)) {
        step.status = "blocked";
        step.guardrail = "Prompt-injection pattern detected in input";
        step.output = "Execution blocked by guardrail before model call.";
        steps.push(step);
        return { status: "blocked", steps, branch };
      }
      if ((agent?.guardrails.piiRedaction || policy?.guardrails.piiRedaction) && /\b[\w.]+@[\w.]+\.\w+\b|\b\d{3}[- ]\d{3}[- ]\d{4}\b/.test(input)) {
        step.guardrail = "PII redacted from prompt (simulated)";
      }
      step.output = branch === "critical" && /analy|classif|audit|research/i.test(label)
        ? "Severity: critical · sentiment: negative · escalation recommended"
        : `${agent?.name ?? "Agent"} completed: ${node.data.description ?? "task done"}`;
    } else if (kind === "tool") {
      if ((forceFail || node.data.simulateFailure) && !failedOnce) {
        failedOnce = true;
        step.status = "failed";
        step.output = `${node.data.tool ?? "Tool"} returned 503 (simulated outage)`;
        steps.push(step);
        return { status: "failed", steps, branch };
      }
      step.output = `${node.data.tool ?? "Tool"}: ok`;
    } else if (kind === "condition") {
      step.output = `Branch → ${branch}`;
    } else if (kind === "approval") {
      const d = decisions[id];
      if (!d) {
        step.status = "paused";
        step.output = "Waiting for human approval";
        steps.push(step);
        return { status: "paused", steps, branch };
      }
      step.status = d;
      step.output = d === "approved" ? "Approved by reviewer" : "Rejected by reviewer";
      if (d === "rejected") {
        steps.push(step);
        return { status: "rejected", steps, branch };
      }
    } else if (kind === "output") {
      step.output = node.data.description ?? "Delivered";
    } else {
      step.output = node.data.description ?? "Done";
    }
    spent += step.cost;
    if (policy?.maxRunCost != null && spent > policy.maxRunCost) {
      step.status = "blocked";
      step.guardrail = `Policy: run cost cap $${policy.maxRunCost} exceeded`;
      steps.push(step);
      return { status: "blocked", steps, branch };
    }
    steps.push(step);

    const out = wf.edges.filter((e) => e.source === id);
    const next = kind === "condition" ? out.filter((e) => !e.label || e.label === branch) : out;
    const chosen = kind === "condition" && next.length === 0 ? out.slice(0, 1) : next;
    chosen.forEach((e) => queue.push(e.target));
  }
  return { status: "completed", steps, branch };
}

export function runTotals(steps: RunStep[]) {
  return steps.reduce(
    (acc, s) => ({ latencyMs: acc.latencyMs + s.latencyMs, tokens: acc.tokens + s.tokens, cost: +(acc.cost + s.cost).toFixed(4) }),
    { latencyMs: 0, tokens: 0, cost: 0 },
  );
}
