// Single source of truth for demo state, persisted to browser storage.
// Components should use the hooks/actions here (the repository layer) so this
// can later be swapped for a Lovable Cloud-backed implementation.
import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import { uid } from "./ids";
import { generateWorkflow, TEMPLATES } from "./templates";
import { simulateRun } from "./simulator";
import type { ActivityEvent, Agent, Connector, ConnectorStatus, KnowledgeSource, MarketplaceAsset, Run, Workflow, WorkflowEdge, WorkflowNode } from "./types";
import { SEED_CONNECTORS, SEED_KNOWLEDGE } from "./catalog";
import { applyInstall, type InstallResult } from "./install";
import { makeAgent } from "./templates";
import { effectivePolicy, roleLabel, type Policy, type Role } from "./governance";

export interface AuditEvent { id: string; at: string; actor: string; role: Role; action: string; target: string }

export const SEED_POLICIES: Policy[] = [
  { id: "pol_inj", scope: "organization", name: "Prompt-injection screening", description: "Every agent screens inputs for injection attempts.", rule: { type: "require-guardrail", guardrail: "injectionDetection" }, enabled: true },
  { id: "pol_pii", scope: "organization", name: "PII redaction", description: "Personal data is redacted before any model call.", rule: { type: "require-guardrail", guardrail: "piiRedaction" }, enabled: true },
  { id: "pol_cost", scope: "organization", name: "Run cost cap", description: "Stop any single run that exceeds the cost cap.", rule: { type: "max-run-cost", usd: 1 }, enabled: true },
  { id: "pol_model", scope: "workspace", name: "No GPT-5 in Acme Ops", description: "Workspace restricts the most expensive model.", rule: { type: "block-model", modelId: "gpt-5" }, enabled: false },
];

interface MeshState {
  workflows: Workflow[];
  agents: Agent[];
  runs: Run[];
  activity: ActivityEvent[];
  connectors: Connector[];
  knowledge: KnowledgeSource[];
  installed: Record<string, string>;
  installAsset: (asset: MarketplaceAsset) => InstallResult;
  setConnectorStatus: (id: string, status: ConnectorStatus, account?: string) => void;
  addKnowledge: (k: Omit<KnowledgeSource, "id" | "updatedAt" | "status">) => string;
  removeKnowledge: (id: string) => void;
  createAgent: () => string;
  createWorkflowFromPrompt: (prompt: string) => string;
  updateGraph: (id: string, nodes: WorkflowNode[], edges: WorkflowEdge[]) => void;
  renameWorkflow: (id: string, name: string) => void;
  duplicateWorkflow: (id: string) => string | undefined;
  deleteWorkflow: (id: string) => void;
  publishWorkflow: (id: string) => number;
  updateAgent: (id: string, patch: Partial<Agent>) => void;
  saveRun: (run: Run) => void;
  log: (e: Omit<ActivityEvent, "id" | "at">) => void;
  resetDemo: () => void;
  role: Role;
  demoStartedAt: string;
  demoHidden: boolean;
  setDemoHidden: (v: boolean) => void;
  setRole: (r: Role) => void;
  policies: Policy[];
  upsertPolicy: (p: Policy) => void;
  removePolicy: (id: string) => void;
  audit: AuditEvent[];
  audited: (action: string, target: string) => void;
  decideApproval: (runId: string, nodeId: string, d: "approved" | "rejected") => Run | undefined;
}

function seed() {
  const inv = generateWorkflow(TEMPLATES[1]!.examplePrompt);
  inv.workflow.status = "published";
  inv.workflow.versions = [{ id: uid("ver"), version: 1, publishedAt: new Date(Date.now() - 86400000 * 3).toISOString(), nodeCount: inv.workflow.nodes.length }];
  const lead = generateWorkflow(TEMPLATES[2]!.examplePrompt);
  const runs: Run[] = [
    { input: "Invoice INV-2291 from Northwind, $4,120.00", d: 2 },
    { input: "Invoice INV-2304 from Contoso, $18,400.00", d: 1, decisions: true },
    { input: "Invoice INV-2310 from Fabrikam, $24,900.00", d: 0.1 },
  ].map(({ input, d, decisions }) => {
    const approvalId = inv.workflow.nodes.find((n) => n.data.kind === "approval")?.id;
    const dec = decisions && approvalId ? { [approvalId]: "approved" as const } : {};
    const r = simulateRun(inv.workflow, inv.agents, input, dec);
    const at = new Date(Date.now() - 86400000 * d).toISOString();
    return { id: uid("run"), workflowId: inv.workflow.id, workflowName: inv.workflow.name, input, status: r.status, steps: r.steps, decisions: dec, startedAt: at, finishedAt: r.status === "paused" ? undefined : at, simulated: true } as Run;
  });
  return {
    workflows: [inv.workflow, lead.workflow],
    agents: [...inv.agents, ...lead.agents],
    runs,
    connectors: SEED_CONNECTORS,
    knowledge: SEED_KNOWLEDGE,
    installed: {} as Record<string, string>,
    role: "admin" as Role,
    demoStartedAt: new Date().toISOString(),
    demoHidden: false,
    policies: SEED_POLICIES,
    audit: [
      { id: uid("aud"), at: inv.workflow.versions[0]!.publishedAt, actor: "Alex Kim", role: "admin" as Role, action: "Published workflow", target: `${inv.workflow.name} v1` },
    ] as AuditEvent[],
    activity: [
      { id: uid("evt"), at: inv.workflow.versions[0]!.publishedAt, kind: "workflow.published", message: `${inv.workflow.name} published as v1`, workflowId: inv.workflow.id },
      { id: uid("evt"), at: runs[1]!.startedAt, kind: "run.completed", message: `${inv.workflow.name} run completed after approval`, workflowId: inv.workflow.id },
    ] as ActivityEvent[],
  };
}

export const useMesh = create<MeshState>()(
  persist(
    (set, get) => ({
      ...seed(),
      log: (e) => set((s) => ({ activity: [{ ...e, id: uid("evt"), at: new Date().toISOString() }, ...s.activity].slice(0, 50) })),
      createWorkflowFromPrompt: (prompt) => {
        const { workflow, agents } = generateWorkflow(prompt);
        set((s) => ({ workflows: [workflow, ...s.workflows], agents: [...agents, ...s.agents] }));
        get().log({ kind: "workflow.created", message: `Generated "${workflow.name}" with ${workflow.nodes.length} steps`, workflowId: workflow.id });
        return workflow.id;
      },
      updateGraph: (id, nodes, edges) =>
        set((s) => ({ workflows: s.workflows.map((w) => (w.id === id ? { ...w, nodes, edges, updatedAt: new Date().toISOString() } : w)) })),
      renameWorkflow: (id, name) =>
        set((s) => ({ workflows: s.workflows.map((w) => (w.id === id ? { ...w, name, updatedAt: new Date().toISOString() } : w)) })),
      duplicateWorkflow: (id) => {
        const w = get().workflows.find((x) => x.id === id);
        if (!w) return;
        const copy: Workflow = { ...w, id: uid("wf"), name: `${w.name} (copy)`, status: "draft", versions: [], createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
        set((s) => ({ workflows: [copy, ...s.workflows] }));
        return copy.id;
      },
      deleteWorkflow: (id) => set((s) => ({ workflows: s.workflows.filter((w) => w.id !== id) })),
      publishWorkflow: (id) => {
        const w = get().workflows.find((x) => x.id === id);
        const version = (w?.versions.length ?? 0) + 1;
        set((s) => ({
          workflows: s.workflows.map((x) =>
            x.id === id
              ? { ...x, status: "published", versions: [...x.versions, { id: uid("ver"), version, publishedAt: new Date().toISOString(), nodeCount: x.nodes.length }] }
              : x,
          ),
        }));
        get().log({ kind: "workflow.published", message: `${w?.name} published as v${version}`, workflowId: id });
        get().audited("Published workflow", `${w?.name} v${version}`);
        return version;
      },
      setDemoHidden: (demoHidden) => set({ demoHidden }),
      updateAgent: (id, patch) => {
        const prev = get().agents.find((a) => a.id === id);
        if (prev && patch.modelId && patch.modelId !== prev.modelId) get().audited("Changed agent model", `${prev.name} → ${patch.modelId}`);
        set((s) => ({ agents: s.agents.map((a) => (a.id === id ? { ...a, ...patch, updatedAt: new Date().toISOString() } : a)) }));
      },
      saveRun: (run) => set((s) => ({ runs: [run, ...s.runs.filter((r) => r.id !== run.id)].slice(0, 200) })),
      resetDemo: () => set(seed()),
      installAsset: (asset) => {
        const r = applyInstall(get(), asset);
        set(r.patch);
        get().log({ kind: "workflow.created", message: `Installed ${asset.name} from marketplace`, workflowId: r.target?.type === "workflow" ? r.target.id : undefined });
        return r;
      },
      setConnectorStatus: (id, status, account) =>
        set((s) => ({ connectors: s.connectors.map((c) => (c.id === id ? { ...c, status, account: status === "demo-connected" ? account ?? c.account ?? "demo account" : undefined } : c)) })),
      addKnowledge: (k) => {
        const id = uid("kn");
        set((s) => ({ knowledge: [{ ...k, id, status: "processing", updatedAt: new Date().toISOString() }, ...s.knowledge] }));
        setTimeout(() => set((s) => ({ knowledge: s.knowledge.map((x) => (x.id === id ? { ...x, status: "ready" } : x)) })), 2500);
        return id;
      },
      removeKnowledge: (id) => {
        const k = get().knowledge.find((x) => x.id === id);
        set((s) => ({ knowledge: s.knowledge.filter((x) => x.id !== id), agents: s.agents.map((a) => ({ ...a, knowledge: a.knowledge.filter((n) => n !== k?.name) })) }));
      },
      setRole: (role) => { set({ role }); get().audited("Switched demo role", roleLabel(role)); },
      upsertPolicy: (p) => {
        const exists = get().policies.some((x) => x.id === p.id);
        set((s) => ({ policies: exists ? s.policies.map((x) => (x.id === p.id ? p : x)) : [...s.policies, p] }));
        get().audited(exists ? (p.enabled ? "Updated policy" : "Disabled policy") : "Created policy", p.name);
      },
      removePolicy: (id) => {
        const p = get().policies.find((x) => x.id === id);
        set((s) => ({ policies: s.policies.filter((x) => x.id !== id) }));
        if (p) get().audited("Deleted policy", p.name);
      },
      audited: (action, target) =>
        set((s) => ({ audit: [{ id: uid("aud"), at: new Date().toISOString(), actor: "Alex Kim", role: s.role, action, target }, ...s.audit].slice(0, 300) })),
      decideApproval: (runId, nodeId, d) => {
        const s = get();
        const run = s.runs.find((r) => r.id === runId);
        const wf = run && s.workflows.find((w) => w.id === run.workflowId);
        if (!run || !wf) return;
        const decisions = { ...run.decisions, [nodeId]: d };
        const sim = simulateRun(wf, s.agents, run.input, decisions, effectivePolicy(s.policies));
        const next: Run = { ...run, decisions, status: sim.status, steps: sim.steps, finishedAt: sim.status === "paused" ? undefined : new Date().toISOString() };
        s.saveRun(next);
        s.log({ kind: "approval.decided", message: `Approval ${d} on ${run.workflowName}`, workflowId: wf.id });
        s.audited(d === "approved" ? "Approved run" : "Rejected run", `${run.workflowName} · ${run.input.slice(0, 40)}`);
        return next;
      },
      createAgent: () => {
        const a = makeAgent({ name: "New Agent", role: "Assistant", purpose: "Describe what this agent does.", instructions: "", modelId: "gpt-5-mini", tools: [], knowledge: [] }, "ws_default");
        set((s) => ({ agents: [a, ...s.agents] }));
        return a.id;
      },
    }),
    {
      name: "mesh-demo-state-v1",
      storage: createJSONStorage(() => localStorage),
      skipHydration: true,
      partialize: (s) => ({ workflows: s.workflows, agents: s.agents, runs: s.runs, activity: s.activity, connectors: s.connectors, knowledge: s.knowledge, installed: s.installed, role: s.role, policies: s.policies, audit: s.audit, demoStartedAt: s.demoStartedAt, demoHidden: s.demoHidden }),
    },
  ),
);
