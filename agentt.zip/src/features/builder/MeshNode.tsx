import { Handle, Position, type NodeProps, type Node } from "@xyflow/react";
import { memo } from "react";
import { Check, Loader2, Pause, X } from "lucide-react";
import { NODE_META } from "./nodeMeta";
import { useMesh } from "@/domain/store";
import { getModel } from "@/domain/models";
import type { WorkflowNodeData } from "@/domain/types";

export type MeshFlowNode = Node<WorkflowNodeData & { runStatus?: string | undefined }, "mesh">;

function MeshNodeImpl({ data, selected }: NodeProps<MeshFlowNode>) {
  const meta = NODE_META[data.kind];
  const agent = useMesh((s) => (data.agentId ? s.agents.find((a) => a.id === data.agentId) : undefined));
  const st = data.runStatus;
  const ring =
    st === "running" ? "border-primary node-running" :
    st === "success" || st === "approved" ? "border-success/60" :
    st === "paused" ? "border-warning" :
    st === "failed" || st === "rejected" || st === "blocked" ? "border-destructive" :
    selected ? "border-primary shadow-lift" : "border-border hover:border-border-accent";

  return (
    <div className={`w-[248px] rounded-xl border bg-background p-3 shadow-soft transition-[border-color,box-shadow] duration-200 ${ring}`}>
      {data.kind !== "trigger" && <Handle type="target" position={Position.Left} />}
      <div className="flex items-start gap-2.5">
        <span className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-lg ${meta.tone}`}>
          <meta.icon className="h-4 w-4" />
        </span>
        <div className="min-w-0 flex-1">
          <p className="truncate text-[13px] font-medium leading-tight">{data.label}</p>
          <p className="mt-0.5 truncate text-[11px] text-muted-foreground">
            {data.kind === "agent" && agent ? `${agent.name} · ${getModel(agent.modelId).name}` : data.tool ?? meta.label}
          </p>
        </div>
        {st && (
          <span className="mt-0.5">
            {st === "running" && <Loader2 className="h-4 w-4 animate-spin text-primary" />}
            {(st === "success" || st === "approved") && <Check className="h-4 w-4 text-success" />}
            {st === "paused" && <Pause className="h-4 w-4 text-warning" />}
            {(st === "failed" || st === "rejected" || st === "blocked") && <X className="h-4 w-4 text-destructive" />}
          </span>
        )}
      </div>
      {data.description && <p className="mt-2 line-clamp-1 text-[11px] text-muted-foreground">{data.description}</p>}
      {data.kind !== "output" && <Handle type="source" position={Position.Right} />}
    </div>
  );
}

export const MeshNode = memo(MeshNodeImpl);
