import "@xyflow/react/dist/style.css";
import {
  Background, BackgroundVariant, Controls, MiniMap, ReactFlow, ReactFlowProvider, addEdge, applyEdgeChanges, applyNodeChanges,
  useReactFlow, type Connection, type Edge, type EdgeChange, type NodeChange,
} from "@xyflow/react";
import { Link, useNavigate } from "@tanstack/react-router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { ArrowLeft, Copy, LayoutTemplate, MoreHorizontal, Play, Plus, Redo2, Rocket, Sparkles, Trash2, Undo2, ChevronDown, ChevronUp, Check } from "lucide-react";
import { toast } from "sonner";
import { useMesh } from "@/domain/store";
import { applyCommand, SUPPORTED_COMMANDS } from "@/domain/commands";
import { autoLayout } from "@/domain/layout";
import { simulateRun } from "@/domain/simulator";
import { can, effectivePolicy } from "@/domain/governance";
import { uid } from "@/domain/ids";
import { makeAgent } from "@/domain/templates";
import type { NodeKind, Run, StepStatus, Workflow, WorkflowEdge, WorkflowNode } from "@/domain/types";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { useIsMobile } from "@/hooks/use-mobile";
import { AgentInspector } from "@/features/agents/AgentInspector";
import { StatusPill } from "@/features/shell/StatusPill";
import { MeshNode, type MeshFlowNode } from "./MeshNode";
import { NODE_META } from "./nodeMeta";
import { SCENARIOS, TestPanel } from "./TestPanel";

const nodeTypes = { mesh: MeshNode };
type Graph = { nodes: WorkflowNode[]; edges: WorkflowEdge[] };
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

const clean = (nodes: MeshFlowNode[]): WorkflowNode[] =>
  nodes.map((n) => ({ id: n.id, type: "mesh", position: n.position, data: { ...n.data, runStatus: undefined } }));

export default function BuilderRoot({ workflow }: { workflow: Workflow }) {
  return (
    <ReactFlowProvider>
      <Builder key={workflow.id} workflow={workflow} />
    </ReactFlowProvider>
  );
}

function Builder({ workflow }: { workflow: Workflow }) {
  const navigate = useNavigate();
  const { fitView } = useReactFlow();
  const store = useMesh();
  const agents = store.agents;
  const [nodes, setNodes] = useState<MeshFlowNode[]>(() => workflow.nodes as MeshFlowNode[]);
  const [edges, setEdges] = useState<WorkflowEdge[]>(workflow.edges);
  const nodesRef = useRef(nodes);
  const edgesRef = useRef(edges);
  nodesRef.current = nodes;
  edgesRef.current = edges;
  const [past, setPast] = useState<Graph[]>([]);
  const [future, setFuture] = useState<Graph[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [panel, setPanel] = useState<"inspector" | "test" | null>(null);
  const [savedAt, setSavedAt] = useState<Date>(new Date(workflow.updatedAt));
  const [composerOpen, setComposerOpen] = useState(() => typeof window === "undefined" || window.innerWidth >= 768);
  const [cmd, setCmd] = useState("");
  const [runState, setRunState] = useState<Record<string, StepStatus | "running">>({});
  const [activeEdges, setActiveEdges] = useState<Set<string>>(new Set());
  const [run, setRun] = useState<Run | null>(null);
  const startRunRef = useRef<() => void>(() => {});
  const isMobile = useIsMobile();
  const [animating, setAnimating] = useState(false);
  const [testInput, setTestInput] = useState(SCENARIOS[0]!.input);
  const cancelRef = useRef(0);

  const commit = useCallback((g: Graph, opts: { history?: boolean } = {}) => {
    if (opts.history !== false) {
      setPast((p) => [...p.slice(-49), { nodes: clean(nodesRef.current), edges: edgesRef.current }]);
      setFuture([]);
    }
    setNodes(g.nodes as MeshFlowNode[]);
    setEdges(g.edges);
    store.updateGraph(workflow.id, clean(g.nodes as MeshFlowNode[]), g.edges);
    setSavedAt(new Date());
  }, [store, workflow.id]);

  const undo = useCallback(() => {
    const prev = past[past.length - 1];
    if (!prev) return;
    setFuture((f) => [{ nodes: clean(nodesRef.current), edges: edgesRef.current }, ...f]);
    setPast((p) => p.slice(0, -1));
    commit(prev, { history: false });
  }, [past, commit]);
  const redo = useCallback(() => {
    const next = future[0];
    if (!next) return;
    setPast((p) => [...p, { nodes: clean(nodesRef.current), edges: edgesRef.current }]);
    setFuture((f) => f.slice(1));
    commit(next, { history: false });
  }, [future, commit]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement;
      if (t.closest("input, textarea, select, [contenteditable]")) return;
      if (e.key === "Escape") { setPanel(null); return; }
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "z") {
        e.preventDefault();
        if (e.shiftKey) redo(); else undo();
      } else if ((e.metaKey || e.ctrlKey) && e.key === "Enter") {
        e.preventDefault();
        setPanel("test");
        startRunRef.current();
      } else if (!e.metaKey && !e.ctrlKey && e.key.toLowerCase() === "f") {
        fitView({ duration: 250, padding: 0.15, maxZoom: 1 });
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [undo, redo, fitView]);

  useEffect(() => {
    const t = setTimeout(() => fitView({ duration: 250, padding: 0.15, maxZoom: 1 }), 60);
    return () => clearTimeout(t);
  }, [panel, fitView]);

  const onNodesChange = useCallback((changes: NodeChange<MeshFlowNode>[]) => {
    const removed = changes.filter((c) => c.type === "remove").map((c) => (c as { id: string }).id);
    const next = applyNodeChanges(changes, nodesRef.current);
    if (removed.length) {
      if (nodesRef.current.some((n) => removed.includes(n.id) && n.data.kind === "trigger")) {
        toast.error("Every workflow needs a trigger.");
        return;
      }
      commit({ nodes: next, edges: edgesRef.current.filter((e) => !removed.includes(e.source) && !removed.includes(e.target)) });
      setSelectedId(null);
      setPanel((p) => (p === "inspector" ? null : p));
    } else {
      setNodes(next);
    }
  }, [commit]);

  const onEdgesChange = useCallback((changes: EdgeChange<Edge>[]) => {
    const next = applyEdgeChanges(changes, edgesRef.current as Edge[]) as unknown as WorkflowEdge[];
    if (changes.some((c) => c.type === "remove")) commit({ nodes: nodesRef.current, edges: next });
    else setEdges(next.map((e) => ({ id: e.id, source: e.source, target: e.target, label: e.label })));
  }, [commit]);

  const onConnect = useCallback((c: Connection) => {
    if (c.source === c.target) return;
    const exists = edgesRef.current.some((e) => e.source === c.source && e.target === c.target);
    if (exists) return;
    const src = nodesRef.current.find((n) => n.id === c.source);
    const label = src?.data.kind === "condition" ? (edgesRef.current.some((e) => e.source === c.source && e.label === "critical") ? "standard" : "critical") : undefined;
    const next = addEdge({ ...c, id: uid("edge"), label } as Edge, edgesRef.current as Edge[]) as unknown as WorkflowEdge[];
    commit({ nodes: nodesRef.current, edges: next.map((e) => ({ id: e.id, source: e.source, target: e.target, label: e.label as string | undefined })) });
  }, [commit]);

  const addNode = (kind: NodeKind, agentId?: string) => {
    const maxX = Math.max(0, ...nodesRef.current.map((n) => n.position.x));
    let aid = agentId;
    if (kind === "agent" && !aid) {
      const a = makeAgent({ name: "New Agent", role: "Assistant", purpose: "Describe what this agent does.", instructions: "", modelId: "gpt-5-mini", tools: [], knowledge: [] }, workflow.workspaceId);
      useMesh.setState((s) => ({ agents: [a, ...s.agents] }));
      aid = a.id;
    }
    const agentName = aid ? useMesh.getState().agents.find((a) => a.id === aid)?.name : undefined;
    const n: MeshFlowNode = { id: uid("node"), type: "mesh", position: { x: maxX + 300, y: 60 }, data: { kind, label: agentName ?? NODE_META[kind].label, description: "", agentId: aid } };
    commit({ nodes: [...nodesRef.current, n], edges: edgesRef.current });
    setSelectedId(n.id);
    setPanel("inspector");
  };

  const tidy = () => {
    commit({ nodes: autoLayout(clean(nodesRef.current), edgesRef.current), edges: edgesRef.current });
    setTimeout(() => fitView({ duration: 300, padding: 0.2 }), 50);
  };

  const runCommand = (text = cmd) => {
    if (!text.trim()) return;
    const r = applyCommand({ nodes: clean(nodesRef.current), edges: edgesRef.current }, text);
    if (!r.ok) {
      toast.error(r.message);
      return;
    }
    commit(r.graph);
    store.audited("Edited by instruction", text);
    setCmd("");
    toast.success(r.message, { description: "Simulated edit · undo with ⌘Z" });
    setTimeout(() => fitView({ duration: 300, padding: 0.2 }), 50);
  };

  // ---- Simulation ----
  const animate = async (steps: Run["steps"], from: number, token: number) => {
    for (let i = from; i < steps.length; i++) {
      if (cancelRef.current !== token) return false;
      const s = steps[i]!;
      const prev = steps[i - 1];
      const edge = prev ? edgesRef.current.find((e) => e.source === prev.nodeId && e.target === s.nodeId) : undefined;
      setActiveEdges(edge ? new Set([edge.id]) : new Set());
      setRunState((r) => ({ ...r, [s.nodeId]: "running" }));
      await sleep(Math.min(900, 280 + s.latencyMs / 4));
      if (cancelRef.current !== token) return false;
      setRunState((r) => ({ ...r, [s.nodeId]: s.status }));
    }
    setActiveEdges(new Set());
    return true;
  };

  const finish = (r: Run) => {
    store.saveRun(r);
    if (r.status === "paused") store.log({ kind: "run.paused", message: `${r.workflowName} paused for approval`, workflowId: workflow.id });
    else if (r.status === "completed") store.log({ kind: "run.completed", message: `${r.workflowName} test run completed`, workflowId: workflow.id });
    else store.log({ kind: "run.failed", message: `${r.workflowName} run ${r.status}`, workflowId: workflow.id });
  };

  const startRun = async () => {
    const token = ++cancelRef.current;
    const sim = simulateRun({ nodes: clean(nodesRef.current), edges: edgesRef.current }, useMesh.getState().agents, testInput, {}, effectivePolicy(useMesh.getState().policies));
    const r: Run = { id: uid("run"), workflowId: workflow.id, workflowName: store.workflows.find((w) => w.id === workflow.id)?.name ?? workflow.name, input: testInput, status: sim.status, steps: sim.steps, decisions: {}, startedAt: new Date().toISOString(), finishedAt: sim.status === "paused" ? undefined : new Date().toISOString(), simulated: true };
    setRunState({});
    setRun({ ...r, steps: [] });
    setAnimating(true);
    for (let i = 0; i < sim.steps.length; i++) {
      // reveal steps progressively in the panel
      setRun((cur) => (cur ? { ...cur, steps: sim.steps.slice(0, i + 1) } : cur));
      if (!(await animate(sim.steps, i, token)) || i === sim.steps.length - 1) break;
      void 0;
    }
    if (cancelRef.current !== token) return;
    setAnimating(false);
    setRun(r);
    finish(r);
  };

  startRunRef.current = startRun;
  const decide = async (nodeId: string, d: "approved" | "rejected") => {
    if (!run) return;
    const token = ++cancelRef.current;
    const decisions = { ...run.decisions, [nodeId]: d };
    const sim = simulateRun({ nodes: clean(nodesRef.current), edges: edgesRef.current }, useMesh.getState().agents, run.input, decisions, effectivePolicy(useMesh.getState().policies));
    const from = run.steps.length - 1;
    store.log({ kind: "approval.decided", message: `Approval ${d} on ${run.workflowName}`, workflowId: workflow.id });
    store.audited(d === "approved" ? "Approved run" : "Rejected run", `${run.workflowName} · test run`);
    setAnimating(true);
    for (let i = from; i < sim.steps.length; i++) {
      setRun((cur) => (cur ? { ...cur, steps: sim.steps.slice(0, i + 1) } : cur));
      if (!(await animate(sim.steps, i, token)) || i === sim.steps.length - 1) break;
    }
    if (cancelRef.current !== token) return;
    const r: Run = { ...run, decisions, status: sim.status, steps: sim.steps, finishedAt: sim.status === "paused" ? undefined : new Date().toISOString() };
    setAnimating(false);
    setRun(r);
    finish(r);
  };

  const closeTest = () => {
    cancelRef.current++;
    setAnimating(false);
    setRunState({});
    setActiveEdges(new Set());
    setPanel(selectedId ? "inspector" : null);
  };

  const current = store.workflows.find((w) => w.id === workflow.id) ?? workflow;
  const publish = () => {
    if (!nodes.some((n) => n.data.kind === "output")) {
      toast.error("Add an output step before publishing.");
      return;
    }
    const v = store.publishWorkflow(workflow.id);
    toast.success(`Published v${v}`, { description: "This version is now the live definition (simulated deployment)." });
  };

  const flowNodes = useMemo(() => nodes.map((n) => ({ ...n, data: { ...n.data, runStatus: runState[n.id] } })), [nodes, runState]);
  const flowEdges: Edge[] = useMemo(
    () => edges.map((e) => ({
      id: e.id, source: e.source, target: e.target, label: e.label, type: "smoothstep",
      className: activeEdges.has(e.id) ? "edge-active" : "",
      labelBgPadding: [6, 3] as [number, number], labelBgBorderRadius: 6,
      labelStyle: { fontSize: 10, fontWeight: 500, fill: "var(--primary-deep)" },
      labelBgStyle: { fill: "var(--highlight)" },
    })),
    [edges, activeEdges],
  );

  const selected = nodes.find((n) => n.id === selectedId);
  const selectedAgent = selected?.data.agentId ? agents.find((a) => a.id === selected.data.agentId) : undefined;
  const updateNodeData = (patch: Partial<WorkflowNode["data"]>) => {
    if (!selected) return;
    commit({ nodes: nodesRef.current.map((n) => (n.id === selected.id ? { ...n, data: { ...n.data, ...patch } } : n)), edges: edgesRef.current });
  };

  return (
    <div className="flex h-full flex-col">
      {/* Toolbar */}
      <div className="flex h-12 shrink-0 items-center gap-2 border-b border-border px-3">
        <Link to="/app/workflows" className="rounded-md p-1.5 text-muted-foreground hover:bg-muted" aria-label="Back to workflows"><ArrowLeft className="h-4 w-4" /></Link>
        <input
          aria-label="Workflow name"
          value={current.name}
          onChange={(e) => store.renameWorkflow(workflow.id, e.target.value)}
          className="w-28 min-w-0 max-w-[280px] flex-1 rounded-md sm:w-auto sm:flex-none bg-transparent px-1.5 py-1 font-medium outline-none hover:bg-muted focus:bg-muted"
        />
        <span className="hidden sm:contents"><StatusPill status={current.status === "published" ? `v${current.versions.length} published` : "draft"} tone={current.status === "published" ? "success" : "neutral"} /></span>
        <span className="hidden items-center gap-1 text-xs text-muted-foreground lg:flex"><Check className="h-3 w-3" />Saved {savedAt.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</span>
        <div className="flex-1" />
        <button onClick={undo} disabled={!past.length} className="hidden rounded-md p-1.5 text-muted-foreground hover:bg-muted disabled:opacity-40 sm:block" aria-label="Undo"><Undo2 className="h-4 w-4" /></button>
        <button onClick={redo} disabled={!future.length} className="hidden rounded-md p-1.5 text-muted-foreground hover:bg-muted disabled:opacity-40 sm:block" aria-label="Redo"><Redo2 className="h-4 w-4" /></button>
        <DropdownMenu>
          <DropdownMenuTrigger className="flex h-8 items-center gap-1 rounded-lg border border-border px-2.5 text-sm hover:border-border-accent"><Plus className="h-4 w-4" /><span className="hidden sm:inline">Add step</span></DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            {(Object.keys(NODE_META) as NodeKind[]).map((k) => {
              const M = NODE_META[k];
              return <DropdownMenuItem key={k} onSelect={() => addNode(k)}><M.icon className="mr-2 h-4 w-4" />{k === "agent" ? "New AI agent" : M.label}</DropdownMenuItem>;
            })}
            {agents.length > 0 && <DropdownMenuSeparator />}
            {agents.length > 0 && <DropdownMenuLabel className="text-xs text-muted-foreground">Reuse an agent</DropdownMenuLabel>}
            {agents.slice(0, 8).map((a) => (
              <DropdownMenuItem key={a.id} onSelect={() => addNode("agent", a.id)}>{a.name}</DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>
        <button aria-label="Test" onClick={() => setPanel("test")} className="flex h-8 items-center gap-1.5 rounded-lg border border-border px-2.5 text-sm hover:border-primary hover:text-primary"><Play className="h-3.5 w-3.5" /><span className="hidden sm:inline">Test</span></button>
        <button aria-label="Publish" onClick={publish} disabled={!can(store.role, "workflow.publish")} title={can(store.role, "workflow.publish") ? "Publish" : "Your demo role cannot publish"} className="disabled:opacity-50 flex h-8 items-center gap-1.5 rounded-lg bg-primary px-3 text-sm font-medium text-primary-foreground hover:bg-primary-deep"><Rocket className="h-3.5 w-3.5" /><span className="hidden sm:inline">Publish</span></button>
        <DropdownMenu>
          <DropdownMenuTrigger className="rounded-md p-1.5 text-muted-foreground hover:bg-muted" aria-label="More actions"><MoreHorizontal className="h-4 w-4" /></DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onSelect={tidy}><LayoutTemplate className="mr-2 h-4 w-4" />Auto-layout</DropdownMenuItem>
            <DropdownMenuItem onSelect={() => { const id = store.duplicateWorkflow(workflow.id); if (id) navigate({ to: "/app/workflows/$id", params: { id } }); }}><Copy className="mr-2 h-4 w-4" />Duplicate</DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuLabel className="text-xs text-muted-foreground">Versions</DropdownMenuLabel>
            {current.versions.length === 0 && <DropdownMenuItem disabled>Not published yet</DropdownMenuItem>}
            {current.versions.slice().reverse().slice(0, 5).map((v) => <DropdownMenuItem key={v.id} disabled>v{v.version} · {new Date(v.publishedAt).toLocaleString()}</DropdownMenuItem>)}
            <DropdownMenuSeparator />
            <DropdownMenuLabel className="text-xs text-muted-foreground">Recent runs</DropdownMenuLabel>
            {store.runs.filter((r) => r.workflowId === workflow.id).slice(0, 5).map((r) => (
              <DropdownMenuItem key={r.id} onSelect={() => { setRun(r); setPanel("test"); setRunState(Object.fromEntries(r.steps.map((s) => [s.nodeId, s.status]))); }}>
                {r.status} · {new Date(r.startedAt).toLocaleTimeString()}
              </DropdownMenuItem>
            ))}
            {!store.runs.some((r) => r.workflowId === workflow.id) && <DropdownMenuItem disabled>No runs yet</DropdownMenuItem>}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <div className="flex min-h-0 flex-1">
        {/* Canvas */}
        <div className="relative min-w-0 flex-1 bg-canvas">
          {isMobile ? (
            <ol className="h-full space-y-2 overflow-y-auto p-4 pb-48" aria-label="Workflow steps">
              {nodes.map((n, i) => {
                const M = NODE_META[n.data.kind];
                const st = runState[n.id];
                return (
                  <li key={n.id}>
                    <button onClick={() => { setSelectedId(n.id); setPanel("inspector"); }} className={`flex w-full items-center gap-3 rounded-xl border bg-background p-3 text-left ${selectedId === n.id ? "border-primary" : "border-border"}`}>
                      <span className="w-5 text-xs text-muted-foreground">{i + 1}</span>
                      <span className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-lg ${M.tone}`}><M.icon className="h-4 w-4" /></span>
                      <span className="min-w-0 flex-1"><span className="block truncate text-sm font-medium">{n.data.label}</span><span className="block truncate text-xs text-muted-foreground">{M.label}</span></span>
                      {st && <StatusPill status={st} />}
                    </button>
                  </li>
                );
              })}
            </ol>
          ) : (
          <ReactFlow
            nodes={flowNodes}
            edges={flowEdges}
            nodeTypes={nodeTypes}
            onNodesChange={onNodesChange}
            onEdgesChange={onEdgesChange}
            onConnect={onConnect}
            onNodeDragStop={() => commit({ nodes: nodesRef.current, edges: edgesRef.current })}
            onNodeClick={(_, n) => { setSelectedId(n.id); if (panel !== "test" || !animating) setPanel("inspector"); }}
            onPaneClick={() => { setSelectedId(null); setPanel((p) => (p === "inspector" ? null : p)); }}
            fitView
            fitViewOptions={{ padding: 0.15, maxZoom: 1 }}
            minZoom={0.2}
            deleteKeyCode={["Backspace", "Delete"]}
            proOptions={{ hideAttribution: true }}
          >
            <Background variant={BackgroundVariant.Dots} gap={20} size={1.2} color="var(--border)" />
            <Controls showInteractive={false} className="!rounded-lg !border !border-border !shadow-soft" />
            <MiniMap pannable zoomable className="!hidden !rounded-lg !border !border-border lg:!block" maskColor="color-mix(in oklab, var(--canvas) 70%, transparent)" nodeColor="var(--border-accent)" />
          </ReactFlow>
          )}

          {/* AI composer */}
          <div className="pointer-events-none absolute inset-x-0 bottom-4 flex justify-center px-4">
            <div className="pointer-events-auto w-full max-w-2xl rounded-2xl border border-border-accent bg-background/95 shadow-lift backdrop-blur">
              <button onClick={() => setComposerOpen((o) => !o)} className="flex w-full items-center gap-2 px-4 py-2 text-xs text-muted-foreground">
                <Sparkles className="h-3.5 w-3.5 text-primary" /> Edit with instructions <span className="text-muted-foreground/70">· simulated</span>
                <span className="flex-1" />
                {composerOpen ? <ChevronDown className="h-3.5 w-3.5" /> : <ChevronUp className="h-3.5 w-3.5" />}
              </button>
              {composerOpen && (
                <div className="px-3 pb-3">
                  <form onSubmit={(e) => { e.preventDefault(); runCommand(); }} className="flex gap-2">
                    <input value={cmd} onChange={(e) => setCmd(e.target.value)} placeholder="e.g. Add human approval before sending emails" aria-label="Instruction" className="min-w-0 flex-1 rounded-lg border border-border bg-background px-3 py-2 text-sm outline-none focus:border-primary" />
                    <button type="submit" className="rounded-lg bg-primary px-3 text-sm font-medium text-primary-foreground hover:bg-primary-deep">Apply</button>
                  </form>
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    {SUPPORTED_COMMANDS.map((c) => (
                      <button key={c} onClick={() => runCommand(c)} className="rounded-full border border-border px-2.5 py-0.5 text-[11px] text-muted-foreground transition-colors hover:border-primary hover:text-primary">{c}</button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right panel */}
        {panel && (
          <aside className="fixed inset-0 z-40 w-full shrink-0 border-l border-border bg-background md:relative md:inset-auto md:z-20 md:max-w-[380px]">
            {panel === "test" ? (
              <TestPanel input={testInput} setInput={setTestInput} run={run} animating={animating} onRun={startRun} onDecide={decide} canDecide={can(store.role, "approval.decide")} onClose={closeTest} />
            ) : selected ? (
              <div className="flex h-full flex-col">
                <div className="flex items-center gap-2 border-b border-border px-4 py-3">
                  {(() => { const M = NODE_META[selected.data.kind]; return <span className={`flex h-7 w-7 items-center justify-center rounded-md ${M.tone}`}><M.icon className="h-3.5 w-3.5" /></span>; })()}
                  <input aria-label="Step name" value={selected.data.label} onChange={(e) => updateNodeData({ label: e.target.value })} className="min-w-0 flex-1 rounded-md bg-transparent px-1 py-0.5 text-sm font-medium outline-none hover:bg-muted focus:bg-muted" />
                  <button onClick={() => onNodesChange([{ type: "remove", id: selected.id }])} className="rounded-md p-1.5 text-muted-foreground hover:bg-muted hover:text-destructive" aria-label="Delete step"><Trash2 className="h-4 w-4" /></button>
                  <button onClick={() => setPanel(null)} className="rounded-md p-1.5 text-muted-foreground hover:bg-muted" aria-label="Close inspector">×</button>
                </div>
                <div className="flex-1 overflow-y-auto p-4">
                  {selectedAgent ? (
                    <>
                      <p className="mb-3 text-xs text-muted-foreground">Reusable agent · edits apply wherever <Link to="/app/agents" search={{ agent: selectedAgent.id }} className="text-primary">{selectedAgent.name}</Link> is used.</p>
                      <AgentInspector agent={selectedAgent} />
                    </>
                  ) : (
                    <div className="space-y-4">
                      <div>
                        <label htmlFor="node-desc" className="mb-1.5 block text-xs font-medium text-muted-foreground">Description</label>
                        <textarea id="node-desc" rows={3} value={selected.data.description ?? ""} onChange={(e) => updateNodeData({ description: e.target.value })} className="w-full rounded-lg border border-border px-3 py-2 text-sm outline-none focus:border-primary" />
                      </div>
                      {selected.data.kind === "tool" && (
                        <label className="flex items-center justify-between rounded-lg border border-border px-3 py-2 text-sm">
                          Simulate failure on next run
                          <input type="checkbox" checked={!!selected.data.simulateFailure} onChange={(e) => updateNodeData({ simulateFailure: e.target.checked })} />
                        </label>
                      )}
                      {selected.data.kind === "condition" && <p className="text-xs text-muted-foreground">Routes on analysed severity. Outgoing connections are labelled <b>critical</b> and <b>standard</b>.</p>}
                      {selected.data.kind === "approval" && <p className="text-xs text-muted-foreground">Runs pause here until a reviewer approves or rejects. Rejection stops the run.</p>}
                      <p className="text-xs text-muted-foreground">{NODE_META[selected.data.kind].label}{selected.data.tool ? ` · ${selected.data.tool} (demo connector)` : ""}</p>
                    </div>
                  )}
                </div>
              </div>
            ) : null}
          </aside>
        )}
      </div>
    </div>
  );
}
