<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Architecture
- Domain logic (types, template generator, command parser, run simulator) lives in `src/domain` as pure functions with tests; UI must not duplicate it. Why: keeps simulation deterministic and testable.
- All demo state goes through the single Zustand store in `src/domain/store.ts` (persisted to localStorage, hydrated client-side in the `/app` layout). Why: one source of truth, swappable for Lovable Cloud later.
- The workflow builder (@xyflow/react) loads client-only via ClientOnly + lazy import. Why: avoids SSR issues with canvas libraries.
- AI generation, model calls, connectors and runs are simulated and must be labelled as such in the UI. Why: no providers are connected.
- Roles/permissions, policy inheritance and run metrics live in `src/domain/governance.ts`; the simulator takes an effective policy so every run path enforces the same rules. Why: one enforcement point for UI, inbox and tests.
