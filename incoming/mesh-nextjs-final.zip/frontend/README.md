# Agentic AI Builder frontend

The active frontend is the Mesh UI from `../incoming/pixel-perfect-match-latest.zip`, migrated to Next.js App Router. It supersedes the old `../agentt.zip` baseline. React, Tailwind, the cinematic landing, and the workflow editor are retained.

## Run locally

Use Node.js 22 or newer. Run from this directory:

```sh
npm ci
npm run dev
```

Open http://localhost:3000. For production, run `npm run build` then `npm start`.

## Verification

```sh
npm run typecheck
npm run lint
npm test
npm run build
PLAYWRIGHT_BROWSERS_PATH=.browser-cache npx playwright install chromium
npm run test:e2e
```

The browser suite starts the production server on port 3100. Package and browser caches stay in this directory. The npm legacy peer resolver is configured because npm 10's default resolver crashed on the archive's optional Vitest peer graph.

## Current behavior

- Create, edit, rename, duplicate, and delete local workflow drafts.
- Add steps, agent hierarchies, and reusable patterns; use layout tools and undo/redo.
- Search and navigate the workspace on desktop and mobile.
- Configure local agent and policy drafts and use template/agent library assets.
- Browser drafts use `mesh-local-drafts-v1`. Existing archive demo storage is neither loaded nor deleted.

Simulated AI generation, connector setup, publishing, test runs, approval decisions, role switching, demo reset/checklists, and pretend knowledge uploads are removed. Backend-dependent pages show unconnected states. Landing-page illustrations remain clearly marked as previews.

This completes baseline migration, not Harihar's backend integration. Local view models and catalogs do not grant permissions or become execution contracts. All API payloads and executable assignments must eventually use the authoritative v1 contracts in `../shared/contracts/`.
