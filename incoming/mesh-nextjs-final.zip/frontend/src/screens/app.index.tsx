"use client";
import { useState } from "react";
import { motion } from "motion/react";
import { Plus, ArrowRight } from "lucide-react";
import { Link, useNavigate } from "@/lib/navigation";
import { useMesh } from "@/domain/store";
export default function Overview() {
  const navigate = useNavigate();
  const create = useMesh((s) => s.createBlankWorkflow);
  const workflows = useMesh((s) => s.workflows);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [error, setError] = useState("");
  const submit = () => {
    if (!name.trim()) { setError("Enter a workflow name."); return; }
    const id = create(name, description.trim());
    navigate({ to: "/app/workflows/$id", params: { id } });
  };
  return <div className="mx-auto max-w-5xl px-6 py-12 md:py-16">
    <motion.h1 initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="text-4xl font-semibold md:text-5xl">What should we automate today?</motion.h1>
    <p className="mt-3 text-muted-foreground">Start a workflow draft and build its steps visually.</p>
    <form onSubmit={(e) => { e.preventDefault(); submit(); }} className="mt-8 rounded-2xl border border-border-accent bg-background p-5 shadow-lift">
      <label htmlFor="workflow-name" className="text-sm font-medium">Workflow name</label>
      <input id="workflow-name" value={name} onChange={(e) => { setName(e.target.value); setError(""); }} placeholder="Name your workflow" maxLength={200} className="mt-2 h-11 w-full rounded-lg border border-border px-3 outline-none focus:border-primary" />
      <label htmlFor="composer" className="mt-4 block text-sm font-medium">Process description</label>
      <textarea id="composer" value={description} onChange={(e) => setDescription(e.target.value)} rows={4} placeholder="Describe the steps, decisions and approvals you want to design." className="mt-2 w-full resize-none rounded-lg border border-border px-3 py-3 outline-none focus:border-primary" />
      <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
        <p className="text-xs text-muted-foreground">Drafts are saved in this browser. AI planning is awaiting backend integration.</p>
        <button type="submit" className="inline-flex h-10 items-center gap-2 rounded-xl bg-primary px-4 text-sm font-medium text-primary-foreground hover:bg-primary-deep"><Plus className="h-4 w-4" />Create draft</button>
      </div>
      {error && <p role="alert" className="mt-2 text-sm text-destructive">{error}</p>}
    </form>
    <section className="mt-14">
      <div className="mb-3 flex items-center justify-between"><h2 className="text-lg font-medium">Recent workflows</h2><Link to="/app/workflows" className="text-sm text-primary">View all</Link></div>
      {workflows.length === 0 ? <p className="rounded-xl border border-dashed border-border p-6 text-sm text-muted-foreground">No drafts yet. Create your first workflow above.</p> : <div className="divide-y divide-border rounded-xl border border-border">{workflows.slice(0, 5).map((w) => <Link key={w.id} to="/app/workflows/$id" params={{ id: w.id }} className="flex items-center justify-between px-4 py-3 hover:bg-canvas"><span><span className="block font-medium">{w.name}</span><span className="text-xs text-muted-foreground">{w.nodes.length} steps · local draft</span></span><ArrowRight className="h-4 w-4 text-primary" /></Link>)}</div>}
    </section>
  </div>;
}
