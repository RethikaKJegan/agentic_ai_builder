"use client";
import { useRouteParams } from "@/lib/navigation";
import { Link } from "@/lib/navigation";
import { ClientOnly } from "@/lib/navigation";
import { lazy, Suspense } from "react";
import { useMesh } from "@/domain/store";

const Builder = lazy(() => import("@/features/builder/Builder"));



export default function WorkflowEditor() {
  const { id } = useRouteParams();
  const workflow = useMesh((s) => s.workflows.find((w) => w.id === id));
  if (!workflow) {
    return (
      <div className="flex h-full flex-col items-center justify-center gap-3 text-center">
        <p className="font-display text-xl font-medium">Workflow not found</p>
        <p className="text-sm text-muted-foreground">This draft is not saved in this browser.</p>
        <Link to="/app/workflows" className="text-sm text-primary">Back to workflows</Link>
      </div>
    );
  }
  const fallback = <div className="flex h-full items-center justify-center bg-canvas text-sm text-muted-foreground">Loading canvas…</div>;
  return (
    <ClientOnly fallback={fallback}>
      <Suspense fallback={fallback}>
        <Builder workflow={workflow} />
      </Suspense>
    </ClientOnly>
  );
}
