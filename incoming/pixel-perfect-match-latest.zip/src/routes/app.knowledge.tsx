import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { FileText, Plus, Search, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { useMesh } from "@/domain/store";
import type { KnowledgeSource } from "@/domain/types";
import { StatusPill } from "@/features/shell/StatusPill";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export const Route = createFileRoute("/app/knowledge")({
  head: () => ({
    meta: [
      { title: "Knowledge — MESH" },
      { name: "description", content: "Knowledge sources and collections your agents can reference." },
      { property: "og:title", content: "Knowledge — MESH" },
      { property: "og:description", content: "Knowledge sources and collections your agents can reference." },
    ],
  }),
  component: Knowledge,
});

const TYPES: KnowledgeSource["fileType"][] = ["PDF", "DOCX", "Markdown", "Web", "CSV"];

function Knowledge() {
  const knowledge = useMesh((s) => s.knowledge);
  const agents = useMesh((s) => s.agents);
  const add = useMesh((s) => s.addKnowledge);
  const remove = useMesh((s) => s.removeKnowledge);
  const [q, setQ] = useState("");
  const [col, setCol] = useState("All");
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: "", collection: "", fileType: "PDF" as KnowledgeSource["fileType"] });
  const [err, setErr] = useState("");

  const collections = useMemo(() => ["All", ...Array.from(new Set(knowledge.map((k) => k.collection)))], [knowledge]);
  const list = knowledge.filter((k) => (col === "All" || k.collection === col) && k.name.toLowerCase().includes(q.toLowerCase()));
  const access = (name: string) => agents.filter((a) => a.knowledge.includes(name));

  const submit = () => {
    if (!form.name.trim() || !form.collection.trim()) {
      setErr("Name and collection are required.");
      return;
    }
    if (knowledge.some((k) => k.name.toLowerCase() === form.name.trim().toLowerCase())) {
      setErr("A source with that name already exists.");
      return;
    }
    add({ name: form.name.trim(), collection: form.collection.trim(), fileType: form.fileType, sizeKb: 40 + Math.round(Math.random() * 400) });
    toast.success(`${form.name} added`, { description: "Processing is simulated and finishes in a few seconds." });
    setOpen(false);
    setForm({ name: "", collection: "", fileType: "PDF" });
  };

  return (
    <div className="mx-auto max-w-5xl px-6 py-10">
      <div className="flex items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-semibold">Knowledge</h1>
          <p className="mt-2 text-sm text-muted-foreground">Seeded demonstration documents. Assign them to agents from the agent's Knowledge tab.</p>
        </div>
        <button onClick={() => { setOpen(true); setErr(""); }} className="inline-flex h-9 shrink-0 items-center gap-1.5 rounded-lg bg-primary px-3.5 text-sm font-medium text-primary-foreground hover:bg-primary-deep"><Plus className="h-4 w-4" />Add source</button>
      </div>

      <div className="mt-6 flex flex-wrap items-center gap-2">
        <div className="relative min-w-[200px] flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input aria-label="Search knowledge" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search sources…" className="h-9 w-full rounded-lg border border-border pl-9 pr-3 text-sm outline-none focus:border-primary" />
        </div>
        <div className="flex flex-wrap gap-1.5">
          {collections.map((c) => (
            <button key={c} onClick={() => setCol(c)} className={`rounded-full px-3 py-1 text-sm ${col === c ? "bg-foreground text-background" : "text-muted-foreground hover:bg-muted"}`}>{c}</button>
          ))}
        </div>
      </div>

      {list.length === 0 ? (
        <p className="mt-8 rounded-xl border border-dashed border-border p-6 text-sm text-muted-foreground">No sources match.</p>
      ) : (
        <div className="mt-6 overflow-x-auto rounded-xl border border-border">
          <table className="w-full min-w-[640px] text-sm">
            <thead className="bg-canvas text-left text-xs text-muted-foreground">
              <tr><th className="px-4 py-2.5 font-medium">Source</th><th className="px-4 py-2.5 font-medium">Collection</th><th className="px-4 py-2.5 font-medium">Status</th><th className="px-4 py-2.5 font-medium">Agent access</th><th className="w-10" /></tr>
            </thead>
            <tbody className="divide-y divide-border">
              {list.map((k) => {
                const users = access(k.name);
                return (
                  <tr key={k.id}>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2.5">
                        <FileText className="h-4 w-4 text-primary" />
                        <div><p className="font-medium">{k.name}</p><p className="text-xs text-muted-foreground">{k.fileType} · {k.sizeKb.toLocaleString()} KB · {new Date(k.updatedAt).toLocaleDateString()}</p></div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">{k.collection}</td>
                    <td className="px-4 py-3"><StatusPill status={k.status} tone={k.status === "ready" ? "success" : k.status === "processing" ? "info" : "danger"} /></td>
                    <td className="px-4 py-3 text-xs">
                      {users.length === 0 ? <span className="text-muted-foreground">None</span> : users.map((u) => <Link key={u.id} to="/app/agents" search={{ agent: u.id }} className="mr-2 text-primary hover:underline">{u.name}</Link>)}
                    </td>
                    <td className="px-2"><button onClick={() => { remove(k.id); toast(`${k.name} removed`); }} className="rounded-md p-1.5 text-muted-foreground hover:bg-muted hover:text-destructive" aria-label={`Remove ${k.name}`}><Trash2 className="h-4 w-4" /></button></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add knowledge source</DialogTitle>
            <DialogDescription>Registers a demo document. File contents aren't uploaded or stored in this prototype.</DialogDescription>
          </DialogHeader>
          <label htmlFor="kn-name" className="text-xs font-medium text-muted-foreground">Name</label>
          <input id="kn-name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="h-10 rounded-lg border border-border px-3 text-sm outline-none focus:border-primary" />
          <label htmlFor="kn-col" className="text-xs font-medium text-muted-foreground">Collection</label>
          <input id="kn-col" list="kn-cols" value={form.collection} onChange={(e) => setForm({ ...form, collection: e.target.value })} className="h-10 rounded-lg border border-border px-3 text-sm outline-none focus:border-primary" />
          <datalist id="kn-cols">{collections.slice(1).map((c) => <option key={c} value={c} />)}</datalist>
          <label htmlFor="kn-type" className="text-xs font-medium text-muted-foreground">Type</label>
          <select id="kn-type" value={form.fileType} onChange={(e) => setForm({ ...form, fileType: e.target.value as KnowledgeSource["fileType"] })} className="h-10 rounded-lg border border-border px-3 text-sm">
            {TYPES.map((t) => <option key={t}>{t}</option>)}
          </select>
          {err && <p role="alert" className="text-sm text-destructive">{err}</p>}
          <div className="flex justify-end gap-2">
            <button onClick={() => setOpen(false)} className="h-9 rounded-lg border border-border px-3 text-sm">Cancel</button>
            <button onClick={submit} className="h-9 rounded-lg bg-primary px-4 text-sm font-medium text-primary-foreground hover:bg-primary-deep">Add source</button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
