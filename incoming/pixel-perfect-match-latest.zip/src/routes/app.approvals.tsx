import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import { useMesh } from "@/domain/store";
import { can } from "@/domain/governance";
import { RunTrace, PageHeader } from "@/features/runs/RunTrace";
import { StatusPill } from "@/features/shell/StatusPill";

export const Route = createFileRoute("/app/approvals")({
  head: () => ({
    meta: [
      { title: "Approvals inbox — MESH" },
      { name: "description", content: "Review paused workflow runs and approve or reject them." },
      { property: "og:title", content: "Approvals inbox — MESH" },
      { property: "og:description", content: "Human-in-the-loop review for agent workflows." },
    ],
  }),
  component: Approvals,
});

function Approvals() {
  const runs = useMesh((s) => s.runs);
  const role = useMesh((s) => s.role);
  const decide = useMesh((s) => s.decideApproval);
  const [open, setOpen] = useState<string | null>(null);
  const pending = runs.filter((r) => r.status === "paused");
  const decided = runs.filter((r) => Object.keys(r.decisions).length > 0 && r.status !== "paused").slice(0, 8);
  const allowed = can(role, "approval.decide");

  return (
    <div className="mx-auto max-w-5xl p-6 md:p-10">
      <PageHeader title="Approvals" sub="Runs paused at a human approval step. Decisions resume the run (simulated)." />
      {!allowed && <p className="mb-4 rounded-lg border border-border bg-canvas p-3 text-sm text-muted-foreground">Your demo role can view but not decide approvals. Switch to Approver or Admin in <Link to="/app/settings" className="text-primary underline">Settings</Link>.</p>}
      {pending.length === 0 && (
        <div className="flex flex-col items-center rounded-2xl border border-dashed border-border py-14 text-center">
          <CheckCircle2 className="h-8 w-8 text-success" />
          <p className="mt-3 font-medium">Inbox clear</p>
          <p className="text-sm text-muted-foreground">Run a critical scenario in a workflow test to create a pending approval.</p>
        </div>
      )}
      <div className="space-y-3">
        {pending.map((r) => {
          const step = r.steps[r.steps.length - 1]!;
          return (
            <div key={r.id} className="rounded-2xl border border-warning/40 bg-background p-5">
              <div className="flex flex-wrap items-start gap-3">
                <div className="min-w-0 flex-1">
                  <p className="text-xs text-muted-foreground">{r.workflowName} · {step.label} · {new Date(r.startedAt).toLocaleString()}</p>
                  <p className="mt-1 font-medium">{r.input}</p>
                </div>
                <StatusPill status="paused" />
              </div>
              <div className="mt-4 flex flex-wrap gap-2">
                <button disabled={!allowed} onClick={() => { const n = decide(r.id, step.nodeId, "approved"); toast.success(`Approved · run ${n?.status}`); }} className="rounded-lg bg-success px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90 disabled:opacity-40">Approve</button>
                <button disabled={!allowed} onClick={() => { decide(r.id, step.nodeId, "rejected"); toast("Rejected · run stopped"); }} className="rounded-lg border border-border px-4 py-2 text-sm font-medium hover:border-destructive hover:text-destructive disabled:opacity-40">Reject</button>
                <button onClick={() => setOpen(open === r.id ? null : r.id)} className="rounded-lg px-3 py-2 text-sm text-muted-foreground hover:bg-muted">{open === r.id ? "Hide trace" : "View trace"}</button>
              </div>
              {open === r.id && <div className="mt-4"><RunTrace steps={r.steps} /></div>}
            </div>
          );
        })}
      </div>
      {decided.length > 0 && (
        <div className="mt-10">
          <h2 className="mb-3 text-sm font-medium text-muted-foreground">Recently decided</h2>
          <div className="divide-y divide-border rounded-2xl border border-border">
            {decided.map((r) => (
              <div key={r.id} className="flex items-center gap-3 px-4 py-3 text-sm">
                <span className="min-w-0 flex-1 truncate">{r.workflowName} · {r.input}</span>
                <StatusPill status={r.status} />
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
