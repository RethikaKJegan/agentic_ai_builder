import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { motion } from "motion/react";
import { ArrowRight, ArrowUpRight, FileText, Headphones, Sparkles, Target, UserPlus } from "lucide-react";
import { demoProgress } from "@/domain/demoProgress";
import { useMesh } from "@/domain/store";
import { TEMPLATES } from "@/domain/templates";
import { runTotals } from "@/domain/simulator";
import { StatusPill } from "@/features/shell/StatusPill";

export const Route = createFileRoute("/app/")({
  head: () => ({
    meta: [
      { title: "Overview — MESH" },
      { name: "description", content: "Describe a business process and generate a multi-agent workflow." },
      { property: "og:title", content: "Overview — MESH" },
      { property: "og:description", content: "Describe a business process and generate a multi-agent workflow." },
    ],
  }),
  component: Overview,
});

const ICONS = { complaint: Headphones, invoice: FileText, lead: Target, onboarding: UserPlus } as const;

function Overview() {
  const { demo } = Route.useSearch();
  const navigate = useNavigate();
  const create = useMesh((s) => s.createWorkflowFromPrompt);
  const workflows = useMesh((s) => s.workflows);
  const runs = useMesh((s) => s.runs);
  const [prompt, setPrompt] = useState(demo === "complaint" ? TEMPLATES[0]!.examplePrompt : "");
  const [error, setError] = useState("");
  const [mode, setMode] = useState<"hierarchy" | "linear">("hierarchy");
  const activity = useMesh((s) => s.activity);
  const audit = useMesh((s) => s.audit);
  const since = useMesh((s) => s.demoStartedAt);
  const demoHidden = useMesh((s) => s.demoHidden);
  const setDemoHidden = useMesh((s) => s.setDemoHidden);
  const steps = demoProgress(activity, audit, since);

  const health = useMemo(() => {
    const done = runs.filter((r) => r.status !== "running" && r.status !== "paused");
    const ok = done.filter((r) => r.status === "completed").length;
    const cost = runs.reduce((a, r) => a + runTotals(r.steps).cost, 0);
    return { total: runs.length, rate: done.length ? Math.round((ok / done.length) * 100) : 0, paused: runs.filter((r) => r.status === "paused").length, cost };
  }, [runs]);

  const submit = () => {
    if (prompt.trim().length < 12) {
      setError("Describe the process in a sentence or two so there's something to build from.");
      return;
    }
    const id = create(prompt.trim(), mode);
    navigate({ to: "/app/workflows/$id", params: { id } });
  };

  return (
    <div className="mx-auto max-w-5xl px-6 py-12 md:py-16">
      <motion.h1 initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }} className="text-4xl font-semibold md:text-5xl">
        What should we automate today?
      </motion.h1>
      <p className="mt-3 text-muted-foreground">Describe a process in plain English. MESH drafts the agents, tools and approvals.</p>

      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.08 }} className="mt-8 rounded-2xl border border-border-accent bg-background p-2 shadow-lift focus-within:border-primary">
        <label htmlFor="composer" className="sr-only">Describe your process</label>
        <textarea
          id="composer"
          value={prompt}
          onChange={(e) => { setPrompt(e.target.value); setError(""); }}
          onKeyDown={(e) => { if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) submit(); }}
          rows={4}
          placeholder="e.g. When a customer complaint arrives, analyse severity, look up the account, draft a reply and escalate critical cases for approval."
          className="w-full resize-none bg-transparent px-4 py-3 text-[15px] leading-relaxed outline-none placeholder:text-muted-foreground/70"
        />
        <div className="flex items-center justify-between gap-3 px-3 pb-2">
          <div className="flex flex-wrap items-center gap-3">
            <div role="radiogroup" aria-label="Workflow structure" className="flex rounded-lg border border-border p-0.5 text-xs">
              {([["hierarchy", "Master + sub-agents"], ["linear", "Linear steps"]] as const).map(([v, l]) => (
                <button key={v} role="radio" aria-checked={mode === v} onClick={() => setMode(v)} className={`rounded-md px-2.5 py-1 ${mode === v ? "bg-highlight font-medium text-primary-deep" : "text-muted-foreground hover:text-foreground"}`}>{l}</button>
              ))}
            </div>
            <p className="text-xs text-muted-foreground">Simulated planning · ⌘↵ to submit</p>
          </div>
          <button onClick={submit} className="inline-flex h-10 items-center gap-2 rounded-xl bg-primary px-4 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary-deep">
            <Sparkles className="h-4 w-4" /> Generate workflow
          </button>
        </div>
      </motion.div>
      {error && <p role="alert" className="mt-2 text-sm text-destructive">{error}</p>}

      {!demoHidden ? (
        <div className="mt-6 rounded-2xl border border-border-accent bg-highlight/40 p-4">
          <div className="flex items-center justify-between gap-3">
            <p className="text-sm font-medium">Investor demo · {steps.filter((s) => s.done).length}/{steps.length}</p>
            <button onClick={() => setDemoHidden(true)} className="text-xs text-muted-foreground hover:text-foreground">Hide</button>
          </div>
          <ol className="mt-3 grid gap-1.5 sm:grid-cols-2 lg:grid-cols-3">
            {steps.map((s, i) => (
              <li key={s.id} className={`flex items-center gap-2 text-sm ${s.done ? "text-muted-foreground line-through" : ""}`}>
                <span className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-[11px] font-medium ${s.done ? "bg-success text-primary-foreground" : "border border-border-accent bg-background"}`}>{s.done ? "✓" : i + 1}</span>
                {s.label}
              </li>
            ))}
            <li className="flex items-center gap-2 text-sm"><span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full border border-border-accent bg-background text-[11px]">7</span><Link to="/app/monitoring" className="text-primary hover:underline">Review results in Monitoring</Link></li>
          </ol>
        </div>
      ) : (
        <button onClick={() => setDemoHidden(false)} className="mt-4 text-xs text-muted-foreground hover:text-foreground">Show investor demo checklist</button>
      )}

      <div className="mt-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
        {TEMPLATES.map((t) => {
          const Icon = ICONS[t.id as keyof typeof ICONS];
          return (
            <button key={t.id} onClick={() => { setPrompt(t.examplePrompt); setError(""); }} className="group flex items-center gap-3 rounded-xl border border-border bg-background p-3 text-left text-sm transition-all hover:border-border-accent hover:bg-highlight/50">
              <Icon className="h-4 w-4 shrink-0 text-primary" />
              <span className="flex-1">{t.name}</span>
              <ArrowUpRight className="h-3.5 w-3.5 text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100" />
            </button>
          );
        })}
      </div>

      <div className="mt-14 grid gap-10 lg:grid-cols-[1fr_280px]">
        <section>
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-lg font-medium">Recent workflows</h2>
            <Link to="/app/workflows" className="text-sm text-primary hover:underline">View all</Link>
          </div>
          {workflows.length === 0 ? (
            <p className="rounded-xl border border-dashed border-border p-6 text-sm text-muted-foreground">No workflows yet. Describe one above to get started.</p>
          ) : (
            <div className="divide-y divide-border rounded-xl border border-border">
              {workflows.slice(0, 5).map((w) => (
                <Link key={w.id} to="/app/workflows/$id" params={{ id: w.id }} className="flex items-center justify-between gap-4 px-4 py-3.5 transition-colors hover:bg-canvas">
                  <div className="min-w-0">
                    <p className="truncate font-medium">{w.name}</p>
                    <p className="text-xs text-muted-foreground">{w.nodes.length} steps · edited {new Date(w.updatedAt).toLocaleDateString()}</p>
                  </div>
                  <StatusPill status={w.status === "published" ? `published v${w.versions.length}` : "draft"} tone={w.status === "published" ? "success" : "neutral"} />
                </Link>
              ))}
            </div>
          )}
        </section>
        <aside className="space-y-8">
          <section>
            <h2 className="mb-3 text-lg font-medium">Health <span className="text-xs font-normal text-muted-foreground">· demo data</span></h2>
            <dl className="grid grid-cols-2 gap-px overflow-hidden rounded-xl border border-border bg-border">
              {[["Runs", health.total], ["Success", `${health.rate}%`], ["Awaiting", health.paused], ["Sim. cost", `$${health.cost.toFixed(3)}`]].map(([k, v]) => (
                <div key={k as string} className="bg-background p-3">
                  <dt className="text-xs text-muted-foreground">{k}</dt>
                  <dd className="mt-1 font-display text-xl font-medium">{v}</dd>
                </div>
              ))}
            </dl>
          </section>
          <section>
            <h2 className="mb-3 text-lg font-medium">Recent runs</h2>
            {runs.length === 0 && <p className="text-sm text-muted-foreground">No runs yet.</p>}
            <ul className="space-y-2">
              {runs.slice(0, 5).map((r) => (
                <li key={r.id}>
                  <Link to="/app/workflows/$id" params={{ id: r.workflowId }} className="flex items-center justify-between gap-2 text-sm hover:text-primary">
                    <span className="truncate">{r.workflowName}</span>
                    <StatusPill status={r.status} />
                  </Link>
                </li>
              ))}
            </ul>
            <Link to="/app/monitoring" className="mt-4 flex items-center gap-1 text-xs text-primary hover:underline">Open monitoring <ArrowRight className="h-3 w-3" /></Link>
          </section>
        </aside>
      </div>
    </div>
  );
}
