import { createFileRoute } from "@tanstack/react-router";
import { Bar, BarChart, CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { useMesh } from "@/domain/store";
import { runMetrics } from "@/domain/governance";
import { PageHeader } from "@/features/runs/RunTrace";

export const Route = createFileRoute("/app/monitoring")({
  head: () => ({
    meta: [
      { title: "Monitoring — MESH" },
      { name: "description", content: "Run volume, success rate, latency and cost computed from simulated runs." },
      { property: "og:title", content: "Monitoring — MESH" },
      { property: "og:description", content: "Operational health of your agent workflows." },
    ],
  }),
  component: Monitoring,
});

function Monitoring() {
  const runs = useMesh((s) => s.runs);
  const m = runMetrics(runs);
  const days = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(Date.now() - (6 - i) * 86400000);
    const key = d.toDateString();
    const dayRuns = runs.filter((r) => new Date(r.startedAt).toDateString() === key);
    const dm = runMetrics(dayRuns);
    return { day: d.toLocaleDateString(undefined, { weekday: "short" }), completed: dm.completed, issues: dm.failed + dm.blocked, paused: dm.pending, cost: dm.cost };
  });
  const byWf = Object.values(
    runs.reduce<Record<string, { name: string; runs: typeof runs }>>((acc, r) => {
      (acc[r.workflowId] ??= { name: r.workflowName, runs: [] }).runs.push(r);
      return acc;
    }, {}),
  ).map((w) => ({ name: w.name, ...runMetrics(w.runs) }));

  const kpis = [
    { label: "Runs", value: m.total.toString() },
    { label: "Success rate", value: `${Math.round(m.successRate * 100)}%` },
    { label: "Avg latency", value: `${(m.avgLatencyMs / 1000).toFixed(1)}s` },
    { label: "Total cost", value: `$${m.cost.toFixed(3)}` },
    { label: "Pending approvals", value: m.pending.toString() },
  ];
  const axis = { stroke: "var(--muted-foreground)", fontSize: 11, tickLine: false, axisLine: false };

  return (
    <div className="mx-auto max-w-6xl p-6 md:p-10">
      <PageHeader title="Monitoring" sub="All figures are computed from simulated run records in this demo workspace." />
      <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
        {kpis.map((k) => (
          <div key={k.label} className="rounded-2xl border border-border p-4">
            <p className="text-xs text-muted-foreground">{k.label}</p>
            <p className="mt-1 font-display text-2xl font-semibold">{k.value}</p>
          </div>
        ))}
      </div>
      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <div className="rounded-2xl border border-border p-4">
          <p className="mb-3 text-sm font-medium">Runs by outcome · last 7 days</p>
          <div className="h-56">
            <ResponsiveContainer>
              <BarChart data={days}>
                <CartesianGrid vertical={false} stroke="var(--border)" />
                <XAxis dataKey="day" {...axis} />
                <YAxis allowDecimals={false} width={24} {...axis} />
                <Tooltip cursor={{ fill: "var(--muted)" }} />
                <Bar dataKey="completed" stackId="a" fill="var(--success)" radius={[0, 0, 0, 0]} />
                <Bar dataKey="paused" stackId="a" fill="var(--warning)" />
                <Bar dataKey="issues" stackId="a" fill="var(--destructive)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="rounded-2xl border border-border p-4">
          <p className="mb-3 text-sm font-medium">Simulated cost (USD) · last 7 days</p>
          <div className="h-56">
            <ResponsiveContainer>
              <LineChart data={days}>
                <CartesianGrid vertical={false} stroke="var(--border)" />
                <XAxis dataKey="day" {...axis} />
                <YAxis width={60} {...axis} />
                <Tooltip />
                <Line type="monotone" dataKey="cost" stroke="var(--primary)" strokeWidth={2} dot={{ r: 3 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
      <div className="mt-6 overflow-x-auto rounded-2xl border border-border">
        <table className="w-full text-sm">
          <thead className="bg-canvas text-left text-xs text-muted-foreground">
            <tr><th className="px-4 py-2.5 font-medium">Workflow</th><th className="px-4 py-2.5 font-medium">Runs</th><th className="px-4 py-2.5 font-medium">Success</th><th className="hidden px-4 py-2.5 font-medium sm:table-cell">Pending</th><th className="hidden px-4 py-2.5 font-medium sm:table-cell">Blocked</th><th className="px-4 py-2.5 font-medium">Cost</th></tr>
          </thead>
          <tbody className="divide-y divide-border">
            {byWf.length === 0 && <tr><td colSpan={6} className="px-4 py-6 text-center text-muted-foreground">No runs yet.</td></tr>}
            {byWf.map((w) => (
              <tr key={w.name}><td className="px-4 py-2.5 font-medium">{w.name}</td><td className="px-4 py-2.5">{w.total}</td><td className="px-4 py-2.5">{Math.round(w.successRate * 100)}%</td><td className="hidden px-4 py-2.5 sm:table-cell">{w.pending}</td><td className="hidden px-4 py-2.5 sm:table-cell">{w.blocked}</td><td className="px-4 py-2.5 font-mono text-xs">${w.cost.toFixed(4)}</td></tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
