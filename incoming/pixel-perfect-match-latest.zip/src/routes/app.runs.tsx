import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { ChevronDown } from "lucide-react";
import { useMesh } from "@/domain/store";
import { runTotals } from "@/domain/simulator";
import { RunTrace, PageHeader } from "@/features/runs/RunTrace";
import { StatusPill } from "@/features/shell/StatusPill";

export const Route = createFileRoute("/app/runs")({
  head: () => ({
    meta: [
      { title: "Run history — MESH" },
      { name: "description", content: "Every simulated workflow run with step-by-step traces." },
      { property: "og:title", content: "Run history — MESH" },
      { property: "og:description", content: "Step-by-step traces for every workflow run." },
    ],
  }),
  component: Runs,
});

const FILTERS = ["all", "completed", "paused", "blocked", "failed", "rejected"] as const;

function Runs() {
  const runs = useMesh((s) => s.runs);
  const [f, setF] = useState<(typeof FILTERS)[number]>("all");
  const [open, setOpen] = useState<string | null>(null);
  const list = runs.filter((r) => f === "all" || r.status === f);

  return (
    <div className="mx-auto max-w-5xl p-6 md:p-10">
      <PageHeader title="Runs" sub="History of simulated executions across all workflows." />
      <div className="mb-4 flex flex-wrap gap-1.5">
        {FILTERS.map((x) => (
          <button key={x} onClick={() => setF(x)} className={`rounded-full border px-3 py-1 text-xs capitalize ${f === x ? "border-primary bg-highlight text-primary-deep" : "border-border text-muted-foreground hover:border-border-accent"}`}>
            {x} {x !== "all" && `(${runs.filter((r) => r.status === x).length})`}
          </button>
        ))}
      </div>
      {list.length === 0 && <p className="rounded-2xl border border-dashed border-border p-10 text-center text-sm text-muted-foreground">No runs match. Test a workflow in the builder to create one.</p>}
      <div className="divide-y divide-border overflow-hidden rounded-2xl border border-border">
        {list.map((r) => {
          const t = runTotals(r.steps);
          return (
            <div key={r.id}>
              <button onClick={() => setOpen(open === r.id ? null : r.id)} className="flex w-full items-center gap-3 px-4 py-3 text-left text-sm hover:bg-canvas">
                <StatusPill status={r.status} />
                <span className="min-w-0 flex-1">
                  <span className="block truncate font-medium">{r.workflowName}</span>
                  <span className="block truncate text-xs text-muted-foreground">{r.input}</span>
                </span>
                <span className="hidden font-mono text-[11px] text-muted-foreground sm:block">{(t.latencyMs / 1000).toFixed(1)}s · ${t.cost.toFixed(4)}</span>
                <span className="hidden w-36 text-right text-xs text-muted-foreground md:block">{new Date(r.startedAt).toLocaleString()}</span>
                <ChevronDown className={`h-4 w-4 text-muted-foreground transition-transform ${open === r.id ? "rotate-180" : ""}`} />
              </button>
              {open === r.id && (
                <div className="bg-canvas px-4 py-4">
                  <div className="mb-3 flex items-center justify-between text-xs text-muted-foreground">
                    <span>Simulated run · {r.steps.length} steps · {t.tokens.toLocaleString()} tokens</span>
                    <Link to="/app/workflows/$id" params={{ id: r.workflowId }} className="text-primary hover:underline">Open workflow</Link>
                  </div>
                  <RunTrace steps={r.steps} />
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
