import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { useMesh } from "@/domain/store";
import type { Connector, ConnectorStatus } from "@/domain/types";
import { StatusPill } from "@/features/shell/StatusPill";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export const Route = createFileRoute("/app/integrations")({
  head: () => ({
    meta: [
      { title: "Integrations — MESH" },
      { name: "description", content: "Demo connectors for communication, CRM, storage, databases and APIs." },
      { property: "og:title", content: "Integrations — MESH" },
      { property: "og:description", content: "Demo connectors for communication, CRM, storage, databases and APIs." },
    ],
  }),
  component: Integrations,
});

const LABEL: Record<ConnectorStatus, [string, "success" | "neutral" | "warning" | "danger"]> = {
  "demo-connected": ["Demo-connected", "success"],
  available: ["Available", "neutral"],
  "needs-config": ["Requires configuration", "warning"],
  error: ["Error", "danger"],
};
const CATS = ["Communication", "CRM", "Storage", "Databases", "HTTP/API", "Productivity"] as const;

function Integrations() {
  const connectors = useMesh((s) => s.connectors);
  const agents = useMesh((s) => s.agents);
  const setStatus = useMesh((s) => s.setConnectorStatus);
  const [setup, setSetup] = useState<Connector | null>(null);
  const [account, setAccount] = useState("");
  const [err, setErr] = useState("");

  const usedBy = (c: Connector) => agents.filter((a) => a.tools.some((t) => c.tools.includes(t)));

  const save = () => {
    if (!setup) return;
    if (account.trim().length < 3) {
      setErr("Enter an account or workspace name to label this demo connection.");
      return;
    }
    setStatus(setup.id, "demo-connected", account.trim());
    toast.success(`${setup.name} connected in demo mode`, { description: "No credentials are stored and no external calls are made." });
    setSetup(null);
  };

  return (
    <div className="mx-auto max-w-5xl px-6 py-10">
      <h1 className="text-3xl font-semibold">Integrations</h1>
      <p className="mt-2 max-w-xl text-sm text-muted-foreground">Connectors give agents tools. In this prototype, connections are simulated — no credentials are collected and no external systems are accessed.</p>

      {CATS.map((cat) => {
        const items = connectors.filter((c) => c.category === cat);
        if (!items.length) return null;
        return (
          <section key={cat} className="mt-10">
            <h2 className="mb-3 text-xs font-medium uppercase tracking-wider text-muted-foreground">{cat}</h2>
            <div className="divide-y divide-border rounded-xl border border-border">
              {items.map((c) => {
                const [label, tone] = LABEL[c.status];
                const users = usedBy(c);
                return (
                  <div key={c.id} className="flex flex-wrap items-center gap-4 px-4 py-4">
                    <span className="flex h-10 w-10 items-center justify-center rounded-lg border border-border bg-canvas font-display text-sm font-semibold">{c.name.slice(0, 2)}</span>
                    <div className="min-w-0 flex-1">
                      <p className="font-medium">{c.name}</p>
                      <p className="text-xs text-muted-foreground">{c.description} · tools: {c.tools.join(", ")}{c.account ? ` · ${c.account}` : ""}</p>
                      {users.length > 0 && <p className="mt-0.5 text-xs text-muted-foreground">Used by {users.map((u) => u.name).slice(0, 3).join(", ")}{users.length > 3 ? ` +${users.length - 3}` : ""}</p>}
                      {c.status === "error" && <p className="mt-0.5 text-xs text-destructive">Simulated error: connection refused. Reconnect to retry.</p>}
                    </div>
                    <StatusPill status={label} tone={tone} />
                    {c.status === "demo-connected" ? (
                      <button onClick={() => { setStatus(c.id, "available"); toast(`${c.name} disconnected`); }} className="h-8 rounded-lg border border-border px-3 text-sm hover:border-destructive hover:text-destructive">Disconnect</button>
                    ) : (
                      <button onClick={() => { setSetup(c); setAccount(""); setErr(""); }} className="h-8 rounded-lg bg-primary px-3 text-sm font-medium text-primary-foreground hover:bg-primary-deep">{c.status === "error" ? "Reconnect" : c.status === "needs-config" ? "Configure" : "Connect"}</button>
                    )}
                  </div>
                );
              })}
            </div>
          </section>
        );
      })}

      <Dialog open={!!setup} onOpenChange={(o) => !o && setSetup(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Connect {setup?.name} (demo)</DialogTitle>
            <DialogDescription>This simulates a connection so agents can use {setup?.tools.join(", ")} in test runs. Nothing is sent to {setup?.name}.</DialogDescription>
          </DialogHeader>
          <label htmlFor="acct" className="text-xs font-medium text-muted-foreground">Account label</label>
          <input id="acct" autoFocus value={account} onChange={(e) => { setAccount(e.target.value); setErr(""); }} onKeyDown={(e) => e.key === "Enter" && save()} placeholder="e.g. acme-support" className="h-10 rounded-lg border border-border px-3 text-sm outline-none focus:border-primary" />
          {err && <p role="alert" className="text-sm text-destructive">{err}</p>}
          <div className="flex justify-end gap-2">
            <button onClick={() => setSetup(null)} className="h-9 rounded-lg border border-border px-3 text-sm">Cancel</button>
            <button onClick={save} className="h-9 rounded-lg bg-primary px-4 text-sm font-medium text-primary-foreground hover:bg-primary-deep">Connect</button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
