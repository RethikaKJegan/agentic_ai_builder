import { createFileRoute } from "@tanstack/react-router";
import { Check } from "lucide-react";
import { toast } from "sonner";
import { useMesh } from "@/domain/store";
import { can, ROLES, type Permission } from "@/domain/governance";
import { PageHeader } from "@/features/runs/RunTrace";

export const Route = createFileRoute("/app/settings")({
  head: () => ({
    meta: [
      { title: "Settings — MESH" },
      { name: "description", content: "Workspace settings, members and demo role switcher." },
      { property: "og:title", content: "Settings — MESH" },
      { property: "og:description", content: "Manage roles and permissions in your MESH workspace." },
    ],
  }),
  component: Settings,
});

const PERMS: { id: Permission; label: string }[] = [
  { id: "workflow.edit", label: "Edit workflows" },
  { id: "workflow.publish", label: "Publish" },
  { id: "run.test", label: "Test runs" },
  { id: "approval.decide", label: "Decide approvals" },
  { id: "policy.manage", label: "Manage policies" },
];

const MEMBERS = [
  { name: "Alex Kim", email: "alex@acme.example", role: "You (demo role below)" },
  { name: "Priya Shah", email: "priya@acme.example", role: "Builder" },
  { name: "Marcus Lee", email: "marcus@acme.example", role: "Approver" },
];

function Settings() {
  const role = useMesh((s) => s.role);
  const setRole = useMesh((s) => s.setRole);
  return (
    <div className="mx-auto max-w-5xl p-6 md:p-10">
      <PageHeader title="Settings" sub="Acme Ops workspace · demo members are sample data." />
      <h2 className="mb-3 text-sm font-medium">Demo role</h2>
      <p className="mb-3 text-sm text-muted-foreground">Switch roles to see permissions enforced across the workspace.</p>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {ROLES.map((r) => (
          <button key={r.id} onClick={() => { setRole(r.id); toast.success(`Now acting as ${r.label}`); }} className={`rounded-2xl border p-4 text-left transition-colors ${role === r.id ? "border-primary bg-highlight" : "border-border hover:border-border-accent"}`}>
            <p className="flex items-center justify-between text-sm font-medium">{r.label}{role === r.id && <Check className="h-4 w-4 text-primary" />}</p>
            <p className="mt-1 text-xs text-muted-foreground">{r.description}</p>
          </button>
        ))}
      </div>
      <div className="mt-8 overflow-x-auto rounded-2xl border border-border">
        <table className="w-full text-sm">
          <thead className="bg-canvas text-left text-xs text-muted-foreground"><tr><th className="px-4 py-2.5 font-medium">Permission</th>{ROLES.map((r) => <th key={r.id} className="px-4 py-2.5 text-center font-medium">{r.label}</th>)}</tr></thead>
          <tbody className="divide-y divide-border">
            {PERMS.map((p) => (
              <tr key={p.id}><td className="px-4 py-2.5">{p.label}</td>{ROLES.map((r) => <td key={r.id} className="px-4 py-2.5 text-center">{can(r.id, p.id) ? <Check className="mx-auto h-4 w-4 text-success" /> : <span className="text-muted-foreground">—</span>}</td>)}</tr>
            ))}
          </tbody>
        </table>
      </div>
      <h2 className="mb-3 mt-8 text-sm font-medium">Members</h2>
      <div className="divide-y divide-border rounded-2xl border border-border">
        {MEMBERS.map((m) => (
          <div key={m.email} className="flex items-center gap-3 px-4 py-3 text-sm">
            <span className="flex h-8 w-8 items-center justify-center rounded-full bg-muted text-xs font-medium">{m.name.split(" ").map((x) => x[0]).join("")}</span>
            <span className="flex-1"><span className="block font-medium">{m.name}</span><span className="text-xs text-muted-foreground">{m.email}</span></span>
            <span className="text-xs text-muted-foreground">{m.role}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
