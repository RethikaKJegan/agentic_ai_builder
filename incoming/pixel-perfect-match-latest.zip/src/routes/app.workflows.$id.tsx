import { createFileRoute, Link } from "@tanstack/react-router";
import { ClientOnly } from "@tanstack/react-router";
import { lazy, Suspense } from "react";
import { useMesh } from "@/domain/store";

const Builder = lazy(() => import("@/features/builder/Builder"));

export const Route = createFileRoute("/app/workflows/$id")({
  head: () => ({
    meta: [
      { title: "Workflow editor — MESH" },
      { name: "description", content: "Design, test and publish a multi-agent workflow on the visual canvas." },
      { property: "og:title", content: "Workflow editor — MESH" },
      { property: "og:description", content: "Design, test and publish a multi-agent workflow." },
    ],
  }),
  component: WorkflowEditor,
});

function WorkflowEditor() {
  const { id } = Route.useParams();
  const workflow = useMesh((s) => s.workflows.find((w) => w.id === id));
  if (!workflow) {
    return (
      <div className="flex h-full flex-col items-center justify-center gap-3 text-center">
        <p className="font-display text-xl font-medium">Workflow not found</p>
        <p className="text-sm text-muted-foreground">It may have been deleted or the demo data was reset.</p>
        <Link to="/app/workflows" className="text-sm text-primary">Back to workflows</Link>
      </div>
    );
  }
  const fallback = <div className="flex h-full items-center justify-center bg-canvas text-sm text-muted-foreground">Loading canvas…</div>;
  return (
    <ClientOnly fallback={fallback}>
      <Suspense fallback={fallback}>
        <Builder workflow={workflow} />
      </Suspense>
    </ClientOnly>
  );
}
