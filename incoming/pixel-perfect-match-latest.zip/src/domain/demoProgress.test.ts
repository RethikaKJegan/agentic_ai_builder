import { describe, expect, it } from "vitest";
import { demoProgress } from "./demoProgress";

const since = "2026-01-02T00:00:00.000Z";
const after = "2026-01-03T00:00:00.000Z";
const before = "2026-01-01T00:00:00.000Z";

describe("investor demo checklist", () => {
  it("ignores events from before the demo started (seed data)", () => {
    const s = demoProgress([{ kind: "workflow.published", at: before }], [], since);
    expect(s.find((x) => x.id === "publish")!.done).toBe(false);
  });
  it("ticks steps from new activity and audit events", () => {
    const s = demoProgress([{ kind: "workflow.created", at: after }, { kind: "run.paused", at: after }], [{ action: "Changed agent model", at: after }], since);
    expect(s.filter((x) => x.done).map((x) => x.id)).toEqual(["generate", "model", "test"]);
  });
});
