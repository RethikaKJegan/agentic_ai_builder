// Investor-demo checklist derived purely from recorded activity and audit events.
import type { ActivityEvent } from "./types";

export interface DemoStep { id: string; label: string; done: boolean }

export function demoProgress(activity: Pick<ActivityEvent, "kind" | "at">[], audit: { action: string; at: string }[], since: string): DemoStep[] {
  const t = new Date(since).getTime();
  const act = activity.filter((a) => new Date(a.at).getTime() >= t).map((a) => a.kind);
  const aud = audit.filter((a) => new Date(a.at).getTime() >= t).map((a) => a.action);
  return [
    { id: "generate", label: "Generate a workflow from a prompt", done: act.includes("workflow.created") },
    { id: "edit", label: "Edit it with an instruction", done: aud.includes("Edited by instruction") },
    { id: "model", label: "Switch an agent's model", done: aud.includes("Changed agent model") },
    { id: "test", label: "Run a simulated test", done: act.some((k) => k === "run.completed" || k === "run.paused" || k === "run.failed") },
    { id: "approve", label: "Decide a human approval", done: act.includes("approval.decided") },
    { id: "publish", label: "Publish a version", done: act.includes("workflow.published") },
  ];
}
