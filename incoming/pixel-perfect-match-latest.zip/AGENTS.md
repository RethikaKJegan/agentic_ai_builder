<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Architecture
- Domain logic (types, template generator, command parser, run simulator) lives in `src/domain` as pure functions with tests; UI must not duplicate it. Why: keeps simulation deterministic and testable.
- All demo state goes through the single Zustand store in `src/domain/store.ts` (persisted to localStorage, hydrated client-side in the `/app` layout). Why: one source of truth, swappable for Lovable Cloud later.
- The workflow builder (@xyflow/react) loads client-only via ClientOnly + lazy import. Why: avoids SSR issues with canvas libraries.
- AI generation, model calls, connectors and runs are simulated and must be labelled as such in the UI. Why: no providers are connected.
- Roles/permissions, policy inheritance, agent controls (`resolveControls`, `checkAgentExecution`, `checkRunStart`) and usage live in `src/domain/governance.ts`; the simulator receives the effective policy plus a control context from `store.controlContext()` so every run path (editor, approvals inbox, tests) enforces the same rules. Why: one enforcement point; UI disabling is never the only guard.
- Master/sub-agent hierarchy logic (planning, depth, collapse, add/remove subtree) lives in `src/domain/hierarchy.ts`, and drop-in workflow patterns in `src/domain/patterns.ts`; hierarchy is expressed through optional node `parentNodeId`/`role` and agent `parentAgentId`. Why: keeps the canvas a plain graph so existing edit, undo, layout and simulation keep working.
- Persisted store changes use the zustand `version` + `migrate` hook and only add data. Why: users must never lose existing demo state on upgrade.
